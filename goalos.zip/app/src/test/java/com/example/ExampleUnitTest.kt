package com.example

import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.Milestone
import com.example.goalos.model.TaskItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class ExampleUnitTest {
    @Test
    fun `scenario - goal can be created with only a title and without a deadline`() {
        val goal = Goal(
            id = UUID.randomUUID().toString(),
            title = "Read 10 Books"
        )
        assertEquals("Read 10 Books", goal.title)
        assertNull(goal.targetDate)
        assertEquals(GoalStatus.ACTIVE, goal.status)
        assertFalse(goal.isOverdue)
        assertFalse(goal.hasDeadline)
    }

    @Test
    fun `scenario - completing a task does not automatically complete a goal`() {
        val goal = Goal(
            id = "g-101",
            title = "Run Marathon",
            status = GoalStatus.ACTIVE
        )
        val task = TaskItem(
            id = "t-1",
            goalId = goal.id,
            title = "Buy running shoes",
            isCompleted = false
        )

        // Complete the task
        val completedTask = task.copy(isCompleted = true, completedAt = System.currentTimeMillis())
        assertTrue(completedTask.isCompleted)

        // Goal must remain ACTIVE and untouched
        assertEquals(GoalStatus.ACTIVE, goal.status)
        assertNull(goal.completedAt)
    }

    @Test
    fun `scenario - completing a milestone does not automatically complete a goal`() {
        val goal = Goal(
            id = "g-202",
            title = "Publish App",
            status = GoalStatus.ACTIVE
        )
        val milestone = Milestone(
            id = "m-1",
            goalId = goal.id,
            title = "Design UI System",
            isCompleted = false
        )

        val completedMilestone = milestone.copy(isCompleted = true, completedAt = System.currentTimeMillis())
        assertTrue(completedMilestone.isCompleted)

        // Goal remains strictly in its defined status
        assertEquals(GoalStatus.ACTIVE, goal.status)
        assertNull(goal.completedAt)
    }

    @Test
    fun `scenario - empty dataset prevents division by zero in pie chart calculation`() {
        val activeCount = 0
        val completedCount = 0
        val pausedCount = 0
        val totalEligible = activeCount + completedCount + pausedCount

        val completedPct = if (totalEligible > 0) (completedCount.toDouble() / totalEligible) * 100.0 else 0.0
        val activePct = if (totalEligible > 0) (activeCount.toDouble() / totalEligible) * 100.0 else 0.0
        val pausedPct = if (totalEligible > 0) (pausedCount.toDouble() / totalEligible) * 100.0 else 0.0

        assertEquals(0.0, completedPct, 0.001)
        assertEquals(0.0, activePct, 0.001)
        assertEquals(0.0, pausedPct, 0.001)
    }

    @Test
    fun `scenario - chart percentages sum to approximately 100 percent when eligible goals exist`() {
        val activeCount = 3
        val completedCount = 5
        val pausedCount = 2
        val totalEligible = activeCount + completedCount + pausedCount // 10

        val completedPct = (completedCount.toDouble() / totalEligible) * 100.0 // 50.0%
        val activePct = (activeCount.toDouble() / totalEligible) * 100.0 // 30.0%
        val pausedPct = (pausedCount.toDouble() / totalEligible) * 100.0 // 20.0%

        assertEquals(50.0, completedPct, 0.001)
        assertEquals(30.0, activePct, 0.001)
        assertEquals(20.0, pausedPct, 0.001)
        assertEquals(100.0, completedPct + activePct + pausedPct, 0.001)
    }

    @Test
    fun `scenario - reopening a goal restores active status without clearing historical data`() {
        val goal = Goal(
            id = "g-303",
            title = "Write Novel",
            status = GoalStatus.COMPLETED,
            completedAt = 1600000000000L
        )

        // Reopening goal
        val reopenedGoal = goal.copy(
            status = GoalStatus.ACTIVE,
            completedAt = null
        )

        assertEquals(GoalStatus.ACTIVE, reopenedGoal.status)
        assertNull(reopenedGoal.completedAt)
        assertEquals("Write Novel", reopenedGoal.title)
    }
}
