package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.goalos.ui.GoalOsApp
import com.example.goalos.ui.GoalOsViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GoalOsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GoalOsApp(viewModel = viewModel)
        }
    }
}
