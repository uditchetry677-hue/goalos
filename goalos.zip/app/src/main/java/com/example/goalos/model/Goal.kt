package com.example.goalos.model

enum class Priority(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    URGENT("Urgent")
}

enum class GoalStatus(val label: String) {
    ACTIVE("Active"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    ARCHIVED("Archived")
}

enum class MetricType(val label: String) {
    SIMPLE("Checklist / Milestones"),
    NUMERIC("Numeric Target"),
    TASKS_BASED("Task-Driven")
}

data class Goal(
    val id: String,
    val title: String,
    val description: String = "",
    val category: String = "General",
    val priority: Priority = Priority.MEDIUM,
    val status: GoalStatus = GoalStatus.ACTIVE,
    val targetDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val pausedAt: Long? = null,
    val metricType: MetricType = MetricType.SIMPLE,
    val currentValue: Double = 0.0,
    val targetValue: Double = 100.0,
    val unit: String = "%",
    val isArchived: Boolean = false
) {
    val isOverdue: Boolean
        get() = targetDate != null && targetDate < System.currentTimeMillis() && status == GoalStatus.ACTIVE

    val hasDeadline: Boolean
        get() = targetDate != null
}
