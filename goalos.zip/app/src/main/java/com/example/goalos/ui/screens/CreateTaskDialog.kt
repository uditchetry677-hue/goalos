package com.example.goalos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.goalos.model.Goal
import com.example.goalos.model.Priority
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTaskDialog(
    goals: List<Goal>,
    preselectedGoalId: String? = null,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String,
        goalId: String?,
        dueDate: Long?,
        priority: Priority,
        durationMinutes: Int?
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedGoalId by remember { mutableStateOf(preselectedGoalId) }
    var priority by remember { mutableStateOf(Priority.MEDIUM) }
    var durationMinutesStr by remember { mutableStateOf("") }
    var isScheduleToday by remember { mutableStateOf(true) }

    var goalDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title *") },
                    modifier = Modifier.fillMaxWidth().testTag("task_input_title"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes / Context (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Optional Goal association
                if (goals.isNotEmpty()) {
                    val currentGoalTitle = goals.firstOrNull { it.id == selectedGoalId }?.title ?: "None (Unassigned Task)"
                    ExposedDropdownMenuBox(
                        expanded = goalDropdownExpanded,
                        onExpandedChange = { goalDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = currentGoalTitle,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Associated Goal (Optional)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = goalDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = goalDropdownExpanded,
                            onDismissRequest = { goalDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (Standalone Task)") },
                                onClick = {
                                    selectedGoalId = null
                                    goalDropdownExpanded = false
                                }
                            )
                            goals.forEach { g ->
                                DropdownMenuItem(
                                    text = { Text(g.title) },
                                    onClick = {
                                        selectedGoalId = g.id
                                        goalDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Schedule toggle
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isScheduleToday,
                        onClick = { isScheduleToday = true },
                        label = { Text("Today's Workspace") }
                    )
                    FilterChip(
                        selected = !isScheduleToday,
                        onClick = { isScheduleToday = false },
                        label = { Text("Unscheduled / Backlog") }
                    )
                }

                // Custom time block
                OutlinedTextField(
                    value = durationMinutesStr,
                    onValueChange = { durationMinutesStr = it },
                    label = { Text("Time Block (Minutes, Optional)") },
                    placeholder = { Text("e.g. 25, 45, 60") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val due = if (isScheduleToday) System.currentTimeMillis() else null
                        val duration = durationMinutesStr.toIntOrNull()
                        onSave(title.trim(), description.trim(), selectedGoalId, due, priority, duration)
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("dialog_save_task_btn")
            ) {
                Text("Create Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
