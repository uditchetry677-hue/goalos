package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.MetricType
import com.example.goalos.model.Priority

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val priority: String,
    val status: String,
    val targetDate: Long?,
    val createdAt: Long,
    val completedAt: Long?,
    val pausedAt: Long?,
    val metricType: String,
    val currentValue: Double,
    val targetValue: Double,
    val unit: String,
    val isArchived: Boolean
) {
    fun toGoal(): Goal = Goal(
        id = id,
        title = title,
        description = description,
        category = category,
        priority = Priority.entries.firstOrNull { it.name == priority } ?: Priority.MEDIUM,
        status = GoalStatus.entries.firstOrNull { it.name == status } ?: GoalStatus.ACTIVE,
        targetDate = targetDate,
        createdAt = createdAt,
        completedAt = completedAt,
        pausedAt = pausedAt,
        metricType = MetricType.entries.firstOrNull { it.name == metricType } ?: MetricType.SIMPLE,
        currentValue = currentValue,
        targetValue = targetValue,
        unit = unit,
        isArchived = isArchived
    )

    companion object {
        fun fromGoal(goal: Goal): GoalEntity = GoalEntity(
            id = goal.id,
            title = goal.title,
            description = goal.description,
            category = goal.category,
            priority = goal.priority.name,
            status = goal.status.name,
            targetDate = goal.targetDate,
            createdAt = goal.createdAt,
            completedAt = goal.completedAt,
            pausedAt = goal.pausedAt,
            metricType = goal.metricType.name,
            currentValue = goal.currentValue,
            targetValue = goal.targetValue,
            unit = goal.unit,
            isArchived = goal.isArchived
        )
    }
}
