package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.GoalHistoryEvent
import com.example.goalos.model.HistoryEventType

@Entity(
    tableName = "history_events",
    indices = [Index(value = ["goalId"])]
)
data class HistoryEventEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val eventType: String,
    val oldValue: String?,
    val newValue: String?,
    val note: String?,
    val timestamp: Long
) {
    fun toHistoryEvent(): GoalHistoryEvent = GoalHistoryEvent(
        id = id,
        goalId = goalId,
        eventType = HistoryEventType.entries.firstOrNull { it.name == eventType } ?: HistoryEventType.CREATED,
        oldValue = oldValue,
        newValue = newValue,
        note = note,
        timestamp = timestamp
    )

    companion object {
        fun fromHistoryEvent(e: GoalHistoryEvent): HistoryEventEntity = HistoryEventEntity(
            id = e.id,
            goalId = e.goalId,
            eventType = e.eventType.name,
            oldValue = e.oldValue,
            newValue = e.newValue,
            note = e.note,
            timestamp = e.timestamp
        )
    }
}
