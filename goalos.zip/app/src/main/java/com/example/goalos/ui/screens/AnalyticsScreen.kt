package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.HistoryEventType
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.components.CalculationInfoDialog
import com.example.goalos.ui.components.GoalPieChart
import com.example.goalos.ui.components.MetricCard
import com.example.goalos.ui.components.WeeklyActivityBarChart
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusOverdueColor
import com.example.goalos.ui.theme.StatusPausedColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ReportingPeriod(val label: String, val days: Int?) {
    ALL_TIME("All Time", null),
    THIS_MONTH("Last 30 Days", 30),
    THIS_WEEK("Last 7 Days", 7)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AnalyticsScreen(
    viewModel: GoalOsViewModel,
    onNavigateToGoals: (GoalStatus?) -> Unit,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val tasks by viewModel.allTasks.collectAsState()
    val milestones by viewModel.allMilestones.collectAsState()
    val events by viewModel.allHistoryEvents.collectAsState()
    val weeklyActivity by viewModel.weeklyActivity.collectAsState()

    var reportingPeriod by remember { mutableStateOf(ReportingPeriod.ALL_TIME) }
    var activeInfoDialog by remember { mutableStateOf<String?>(null) }

    val now = System.currentTimeMillis()
    val periodStartTimestamp = reportingPeriod.days?.let { now - (it * 86400000L) } ?: 0L

    // Separate datasets strictly per requirements:
    // A. Goal completion
    val eligibleGoals = goals.filter { !it.isArchived && it.createdAt >= periodStartTimestamp }
    val activeGoalsCount = eligibleGoals.count { it.status == GoalStatus.ACTIVE }
    val completedGoalsCount = eligibleGoals.count { it.status == GoalStatus.COMPLETED }
    val pausedGoalsCount = eligibleGoals.count { it.status == GoalStatus.PAUSED }
    val totalEligible = eligibleGoals.size

    val goalCompletionPct = if (totalEligible > 0) (completedGoalsCount.toDouble() / totalEligible) * 100.0 else 0.0

    // B. Task completion
    val periodTasks = tasks.filter { it.createdAt >= periodStartTimestamp }
    val completedTasksCount = periodTasks.count { it.isCompleted }
    val totalTasksCount = periodTasks.size
    val taskCompletionPct = if (totalTasksCount > 0) (completedTasksCount.toDouble() / totalTasksCount) * 100.0 else 0.0

    // C. Milestone completion
    val totalMilestones = milestones.size
    val completedMilestones = milestones.count { it.isCompleted }
    val milestoneCompletionPct = if (totalMilestones > 0) (completedMilestones.toDouble() / totalMilestones) * 100.0 else 0.0

    // Category distribution
    val categoryCounts = eligibleGoals.groupBy { it.category }

    // Deadline performance (completed goals that had target dates)
    val completedWithTarget = goals.filter { it.status == GoalStatus.COMPLETED && it.targetDate != null && it.completedAt != null }
    val onTimeCompleted = completedWithTarget.count { it.completedAt!! <= it.targetDate!! }
    val lateCompleted = completedWithTarget.count { it.completedAt!! > it.targetDate!! }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Page Title & Integrity Notice
        item {
            Column {
                Text(
                    text = "Honest Analytics & Performance",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Progress metrics remain strictly distinct. Task completion is never confused with goal achievement.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Reporting Period Selector
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportingPeriod.entries.forEach { period ->
                    item {
                        FilterChip(
                            selected = reportingPeriod == period,
                            onClick = { reportingPeriod = period },
                            label = { Text(period.label) },
                            modifier = Modifier.testTag("period_${period.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // 1. Goal Status Distribution (Pie Chart)
        item {
            GoalPieChart(
                activeCount = activeGoalsCount,
                completedCount = completedGoalsCount,
                pausedCount = pausedGoalsCount,
                archivedCount = 0,
                includeArchived = false,
                onSelectStatus = onNavigateToGoals
            )
        }

        // 2. Distinct Metric Cards (Section A vs B vs C)
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Separate Progress Dimensions",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = { activeInfoDialog = "Distinct Dimensions" }) {
                        Icon(Icons.Default.Info, contentDescription = "Explain Formulas", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "Goal Outcomes",
                        value = if (totalEligible > 0) String.format("%.0f%%", goalCompletionPct) else "None",
                        subtitle = "$completedGoalsCount of $totalEligible goals reached",
                        icon = Icons.Default.Flag,
                        iconTint = StatusCompletedColor,
                        onClick = { activeInfoDialog = "Goal Outcomes" },
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Task Execution",
                        value = if (totalTasksCount > 0) String.format("%.0f%%", taskCompletionPct) else "None",
                        subtitle = "$completedTasksCount of $totalTasksCount tasks done",
                        icon = Icons.Default.CheckCircle,
                        iconTint = MaterialTheme.colorScheme.primary,
                        onClick = { activeInfoDialog = "Task Execution" },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "Milestone Advancement",
                        value = if (totalMilestones > 0) String.format("%.0f%%", milestoneCompletionPct) else "None",
                        subtitle = "$completedMilestones of $totalMilestones reached",
                        icon = Icons.AutoMirrored.Filled.TrendingUp,
                        iconTint = StatusActiveColor,
                        onClick = { activeInfoDialog = "Milestones" },
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Deadline Reliability",
                        value = if (completedWithTarget.isNotEmpty()) "$onTimeCompleted on time" else "Unavailable",
                        subtitle = if (completedWithTarget.isNotEmpty()) "$lateCompleted completed late" else "Needs completed deadlines",
                        icon = Icons.Default.Schedule,
                        iconTint = StatusActiveColor,
                        onClick = { activeInfoDialog = "Deadline Reliability" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. Weekly Activity Chart
        item {
            WeeklyActivityBarChart(activityDays = weeklyActivity)
        }

        // 4. Category Breakdown
        if (categoryCounts.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Category Distribution",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        categoryCounts.forEach { (cat, list) ->
                            val completedInCat = list.count { it.status == GoalStatus.COMPLETED }
                            val catFraction = (list.size.toFloat() / totalEligible).coerceIn(0f, 1f)

                            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = cat,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${list.size} goals ($completedInCat completed)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { catFraction },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Completed Goal History
        val completedGoalsList = goals.filter { it.status == GoalStatus.COMPLETED }
        if (completedGoalsList.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Completed Goal History (${completedGoalsList.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        completedGoalsList.forEach { goal ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = StatusCompletedColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = goal.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = goal.completedAt?.let { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(it)) } ?: "Completed",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Formula dialogs
    activeInfoDialog?.let { dialogType ->
        when (dialogType) {
            "Goal Outcomes" -> {
                CalculationInfoDialog(
                    metricTitle = "Goal Outcomes Percentage",
                    formula = "Completed Eligible Goals / Total Eligible Goals × 100",
                    explanation = "Measures the high-level objectives that have been successfully finalized. Paused and active goals form the remainder of the baseline.",
                    dataDistinctions = "Does NOT bundle task ticks into goal completion. A goal is only completed when explicitly verified and marked complete.",
                    onDismiss = { activeInfoDialog = null }
                )
            }
            "Task Execution" -> {
                CalculationInfoDialog(
                    metricTitle = "Task Execution Percentage",
                    formula = "Completed Tasks / Total Tasks in Period × 100",
                    explanation = "Reflects execution throughput on daily steps and checklist items.",
                    dataDistinctions = "Shows work output. Completing 10 easy tasks shows high task execution, but remains mathematically separated from goal outcome achievement.",
                    onDismiss = { activeInfoDialog = null }
                )
            }
            "Deadline Reliability" -> {
                CalculationInfoDialog(
                    metricTitle = "Deadline Reliability",
                    formula = "Count(goals where completedAt <= targetDate) vs Count(goals where completedAt > targetDate)",
                    explanation = "Shows on-time delivery across goals that had planned target dates.",
                    dataDistinctions = "Goals without deadlines are treated as open-ended and deliberately excluded from deadline lateness statistics.",
                    onDismiss = { activeInfoDialog = null }
                )
            }
            else -> {
                CalculationInfoDialog(
                    metricTitle = "Distinct Metrics System",
                    formula = "Goal Completion != Task Completion != Milestone Completion",
                    explanation = "GoalOS strictly maintains separate indicators for each dimension of personal progress to eliminate vanity metrics.",
                    dataDistinctions = "Zero values indicate measured zero activity. Unavailable metrics are omitted rather than simulated.",
                    onDismiss = { activeInfoDialog = null }
                )
            }
        }
    }
}
