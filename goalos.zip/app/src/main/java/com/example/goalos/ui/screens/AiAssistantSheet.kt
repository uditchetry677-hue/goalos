package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.goalos.ai.ProposedMilestone
import com.example.goalos.ai.ProposedTask
import com.example.goalos.model.Goal
import com.example.goalos.ui.GoalOsViewModel
import com.example.BuildConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantSheet(
    targetGoal: Goal?,
    allGoals: List<Goal>,
    viewModel: GoalOsViewModel,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val proposal by viewModel.aiProposal.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()

    var goalTitle by remember { mutableStateOf(targetGoal?.title ?: "") }
    var contextNotes by remember { mutableStateOf(targetGoal?.description ?: "") }
    var timelineDaysStr by remember { mutableStateOf("30") }
    var selectedGoalId by remember { mutableStateOf(targetGoal?.id) }

    ModalBottomSheet(
        onDismissRequest = {
            viewModel.clearAiProposal()
            onDismiss()
        },
        sheetState = sheetState,
        modifier = modifier.testTag("ai_assistant_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Goal Architecture Assistant",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Drafts editable milestones & steps. Nothing is saved without your approval.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (proposal == null) {
                // Input form
                OutlinedTextField(
                    value = goalTitle,
                    onValueChange = { goalTitle = it },
                    label = { Text("Goal or Objective *") },
                    placeholder = { Text("e.g. Build an open-source Android app") },
                    modifier = Modifier.fillMaxWidth().testTag("ai_goal_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = contextNotes,
                    onValueChange = { contextNotes = it },
                    label = { Text("Constraints or Context (Optional)") },
                    placeholder = { Text("e.g. 1 hour per evening, starting from zero Kotlin experience") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = timelineDaysStr,
                    onValueChange = { timelineDaysStr = it },
                    label = { Text("Timeline Target (Days)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Button(
                    onClick = {
                        val key = try {
                            BuildConfig.GEMINI_API_KEY
                        } catch (e: Exception) {
                            ""
                        }
                        viewModel.requestAiGoalBreakdown(
                            goalTitle = goalTitle,
                            description = contextNotes,
                            timelineDays = timelineDaysStr.toIntOrNull() ?: 30,
                            apiKey = key
                        )
                    },
                    enabled = goalTitle.isNotBlank() && !isLoading,
                    modifier = Modifier.fillMaxWidth().testTag("ai_generate_proposal_btn")
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Drafting Roadmap...")
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Draft Architecture Proposal")
                    }
                }
            } else {
                // Proposal Review State (fully editable!)
                val activeProposal = proposal!!

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Proposed Strategy: ${activeProposal.goalTitle}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activeProposal.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Proposed Milestones (Editable)
                Text(
                    text = "Proposed Milestones (Review & Edit)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    activeProposal.proposedMilestones.forEachIndexed { index, m ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = m.title,
                                onValueChange = { newTitle ->
                                    m.title = newTitle
                                },
                                label = { Text("Milestone ${index + 1}") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }

                // Proposed Tasks (Editable)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "First Practical Tasks (Review & Edit)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    activeProposal.proposedTasks.forEachIndexed { index, t ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = t.title,
                                onValueChange = { newTitle ->
                                    t.title = newTitle
                                },
                                label = { Text("Task ${index + 1} (${t.estimatedMinutes ?: 30}m)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }

                // Actions: Apply or Discard
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.clearAiProposal() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Discard")
                    }
                    Button(
                        onClick = {
                            val effectiveGoalId = selectedGoalId ?: viewModel.createGoal(
                                title = activeProposal.goalTitle,
                                description = activeProposal.summary
                            )
                            viewModel.applyAiProposal(effectiveGoalId, activeProposal)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f).testTag("ai_apply_proposal_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve & Save")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
