package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.MetricType
import com.example.goalos.model.Priority
import com.example.goalos.model.TaskItem
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.components.CalculationInfoDialog
import com.example.goalos.ui.components.GoalPieChart
import com.example.goalos.ui.components.MetricCard
import com.example.goalos.ui.components.WeeklyActivityBarChart
import com.example.goalos.ui.theme.PriorityHighColor
import com.example.goalos.ui.theme.PriorityLowColor
import com.example.goalos.ui.theme.PriorityMediumColor
import com.example.goalos.ui.theme.PriorityUrgentColor
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusOverdueColor
import com.example.goalos.ui.theme.StatusPausedColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: GoalOsViewModel,
    onNavigateToGoals: (GoalStatus?) -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToGoalDetail: (String) -> Unit,
    onOpenAddGoalDialog: () -> Unit,
    onOpenAddTaskDialog: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val allMilestones by viewModel.allMilestones.collectAsState()
    val weeklyActivity by viewModel.weeklyActivity.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsState()

    var showMetricInfo by remember { mutableStateOf<String?>(null) }
    var quickTaskText by remember { mutableStateOf("") }

    val activeGoals = goals.filter { it.status == GoalStatus.ACTIVE && !it.isArchived }
    val completedGoals = goals.filter { it.status == GoalStatus.COMPLETED && !it.isArchived }
    val pausedGoals = goals.filter { it.status == GoalStatus.PAUSED && !it.isArchived }
    val archivedGoals = goals.filter { it.isArchived || it.status == GoalStatus.ARCHIVED }

    val now = System.currentTimeMillis()
    val sevenDaysAhead = now + (7 * 86400000L)
    val approachingDeadlines = activeGoals.filter { it.targetDate != null && it.targetDate in now..sevenDaysAhead }
    val overdueGoals = activeGoals.filter { it.targetDate != null && it.targetDate < now }

    // Today's tasks (due today or scheduled today)
    val startOfToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val endOfToday = startOfToday + 86400000L - 1L

    val todayTasks = allTasks.filter { task ->
        task.dueDate != null && task.dueDate in startOfToday..endOfToday
    }

    val todayCompletedTasks = allTasks.count {
        it.isCompleted && it.completedAt != null && it.completedAt in startOfToday..endOfToday
    }

    val weekAgo = now - (7 * 86400000L)
    val monthAgo = now - (30 * 86400000L)
    val weekCompletedTasks = allTasks.count {
        it.isCompleted && it.completedAt != null && it.completedAt >= weekAgo
    }
    val goalsCompletedThisWeek = completedGoals.count {
        it.completedAt != null && it.completedAt >= weekAgo
    }
    val goalsCompletedThisMonth = completedGoals.count {
        it.completedAt != null && it.completedAt >= monthAgo
    }

    val totalEligibleGoals = activeGoals.size + completedGoals.size + pausedGoals.size
    val overallProgressPercent = if (totalEligibleGoals > 0) {
        (completedGoals.size.toDouble() / totalEligibleGoals) * 100.0
    } else 0.0

    // Greeting logic
    val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when (currentHour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        else -> "Good evening"
    }
    val todayDateFormatted = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 16.dp,
            bottom = 96.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header & Daily Focus
        if (userSettings.showGreetingWidget) {
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "$greeting • GoalOS",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = todayDateFormatted,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Focus on what matters today. Measure genuine progress.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Prominent Primary Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onOpenAddGoalDialog,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_add_goal_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Goal")
                        }
                        OutlinedButton(
                            onClick = { onOpenAddTaskDialog(null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_add_task_btn")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Task")
                        }
                    }
                }
            }
        }

        // 2. Summary Metric Cards
        if (userSettings.showSummaryCards && totalEligibleGoals > 0) {
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Metrics",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(onClick = { showMetricInfo = "Live Metrics" }) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = "Explain Formulas",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        maxItemsInEachRow = 2
                    ) {
                        MetricCard(
                            title = "Active Goals",
                            value = "${activeGoals.size}",
                            subtitle = if (approachingDeadlines.isNotEmpty()) "${approachingDeadlines.size} due this week" else "On track",
                            icon = Icons.Default.Flag,
                            iconTint = StatusActiveColor,
                            onClick = { onNavigateToGoals(GoalStatus.ACTIVE) },
                            modifier = Modifier.weight(1f),
                            testTag = "card_active_goals"
                        )
                        MetricCard(
                            title = "Completed Goals",
                            value = "${completedGoals.size}",
                            subtitle = "$goalsCompletedThisMonth this month",
                            icon = Icons.Default.CheckCircle,
                            iconTint = StatusCompletedColor,
                            onClick = { onNavigateToGoals(GoalStatus.COMPLETED) },
                            modifier = Modifier.weight(1f),
                            testTag = "card_completed_goals"
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        maxItemsInEachRow = 2
                    ) {
                        MetricCard(
                            title = "Tasks Completed",
                            value = "$todayCompletedTasks today",
                            subtitle = "$weekCompletedTasks this week",
                            icon = Icons.Default.CheckCircle,
                            iconTint = MaterialTheme.colorScheme.primary,
                            onClick = onNavigateToTasks,
                            modifier = Modifier.weight(1f),
                            testTag = "card_tasks_completed"
                        )
                        MetricCard(
                            title = "Overall Goal Progress",
                            value = String.format("%.0f%%", overallProgressPercent),
                            subtitle = "${completedGoals.size} of $totalEligibleGoals completed",
                            icon = Icons.AutoMirrored.Filled.TrendingUp,
                            iconTint = StatusCompletedColor,
                            onClick = { showMetricInfo = "Overall Goal Progress" },
                            modifier = Modifier.weight(1f),
                            testTag = "card_overall_progress"
                        )
                    }
                }
            }
        }

        // 3. Primary Feature: Automatic Goal-Completion Pie Chart
        if (userSettings.showPieChartWidget) {
            item {
                GoalPieChart(
                    activeCount = activeGoals.size,
                    completedCount = completedGoals.size,
                    pausedCount = pausedGoals.size,
                    archivedCount = archivedGoals.size,
                    includeArchived = false,
                    selectedStatus = selectedStatusFilter,
                    onSelectStatus = { status ->
                        viewModel.setSelectedStatusFilter(status)
                        if (status != null) {
                            onNavigateToGoals(status)
                        }
                    },
                    onAddGoalClick = onOpenAddGoalDialog
                )
            }
        }

        // 4. Deadlines & Approaching Milestones Notice
        if (overdueGoals.isNotEmpty() || approachingDeadlines.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(
                            1.dp,
                            if (overdueGoals.isNotEmpty()) StatusOverdueColor.copy(alpha = 0.4f) else StatusPausedColor.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        )
                        .testTag("deadlines_notice_card"),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = null,
                                tint = if (overdueGoals.isNotEmpty()) StatusOverdueColor else StatusPausedColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Upcoming & Overdue Deadlines",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        if (overdueGoals.isNotEmpty()) {
                            Text(
                                text = "• ${overdueGoals.size} goal(s) reached their planned deadline and remain active.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusOverdueColor
                            )
                        }
                        if (approachingDeadlines.isNotEmpty()) {
                            Text(
                                text = "• ${approachingDeadlines.size} goal(s) approaching deadline within 7 days.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 5. Today's Tasks
        if (userSettings.showTodayTasksWidget) {
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Today's Tasks (${todayTasks.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TextButton(onClick = onNavigateToTasks) {
                            Text("View All")
                        }
                    }

                    if (todayTasks.isEmpty()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "No tasks scheduled for today. Add a task or enjoy your open focus time.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            todayTasks.take(5).forEach { task ->
                                val linkedGoal = goals.firstOrNull { it.id == task.goalId }
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                                        .testTag("dashboard_task_item_${task.id}"),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = task.isCompleted,
                                            onCheckedChange = { checked ->
                                                viewModel.toggleTask(task, checked)
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Medium,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                            )
                                            if (linkedGoal != null) {
                                                Text(
                                                    text = "Goal: ${linkedGoal.title}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                        // Priority badge
                                        val prioColor = when (task.priority) {
                                            Priority.LOW -> PriorityLowColor
                                            Priority.MEDIUM -> PriorityMediumColor
                                            Priority.HIGH -> PriorityHighColor
                                            Priority.URGENT -> PriorityUrgentColor
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(1.dp, prioColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = task.priority.label,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = prioColor,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Quick Capture Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = quickTaskText,
                        onValueChange = { quickTaskText = it },
                        placeholder = { Text("Quick capture an idea or task...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_task_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (quickTaskText.isNotBlank()) {
                                viewModel.createTask(
                                    title = quickTaskText.trim(),
                                    dueDate = System.currentTimeMillis()
                                )
                                quickTaskText = ""
                            }
                        },
                        enabled = quickTaskText.isNotBlank(),
                        modifier = Modifier.testTag("quick_task_submit_btn")
                    ) {
                        Text("Add")
                    }
                }
            }
        }

        // 7. Active Goals with Compact Progress
        if (userSettings.showActiveGoalsWidget && activeGoals.isNotEmpty()) {
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active Goals (${activeGoals.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TextButton(onClick = { onNavigateToGoals(GoalStatus.ACTIVE) }) {
                            Text("See All")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        activeGoals.take(4).forEach { goal ->
                            val goalMilestones = allMilestones.filter { it.goalId == goal.id }
                            val completedMCount = goalMilestones.count { it.isCompleted }
                            val totalMCount = goalMilestones.size

                            val progressFraction = when (goal.metricType) {
                                MetricType.NUMERIC -> if (goal.targetValue > 0) (goal.currentValue / goal.targetValue).toFloat().coerceIn(0f, 1f) else 0f
                                MetricType.SIMPLE -> if (totalMCount > 0) (completedMCount.toFloat() / totalMCount) else 0f
                                MetricType.TASKS_BASED -> {
                                    val tasksForGoal = allTasks.filter { it.goalId == goal.id }
                                    if (tasksForGoal.isNotEmpty()) (tasksForGoal.count { it.isCompleted }.toFloat() / tasksForGoal.size) else 0f
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                                    .clickable { onNavigateToGoalDetail(goal.id) }
                                    .testTag("dashboard_goal_card_${goal.id}"),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = goal.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = String.format("%.0f%%", progressFraction * 100),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { progressFraction },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = goal.category,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (goal.targetDate != null) {
                                            Text(
                                                text = "Due ${SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(goal.targetDate))}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (goal.isOverdue) StatusOverdueColor else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            Text(
                                                text = "No deadline",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 8. 7-Day Activity Chart
        if (userSettings.showActivityChartWidget) {
            item {
                WeeklyActivityBarChart(activityDays = weeklyActivity)
            }
        }

        // 9. Weekly Review Summary
        if (userSettings.showWeeklyReviewWidget && totalEligibleGoals > 0) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Weekly Review Insight",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Over the past 7 days, you finished $weekCompletedTasks task(s) and reached completion on $goalsCompletedThisWeek goal(s). Remember: steady, realistic progress creates sustainable results.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // Calculation Info Dialog
    showMetricInfo?.let { metric ->
        when (metric) {
            "Overall Goal Progress" -> {
                CalculationInfoDialog(
                    metricTitle = "Overall Goal Progress",
                    formula = "Completed Eligible Goals / Total Eligible Goals × 100",
                    explanation = "Reflects the proportion of defined goals that have reached full completion. Paused and active goals count towards the denominator. Archived goals are excluded.",
                    dataDistinctions = "Task completion is kept distinct from goal completion: checking tasks does not artificially inflate goal completion.",
                    onDismiss = { showMetricInfo = null }
                )
            }
            else -> {
                CalculationInfoDialog(
                    metricTitle = "Dashboard Analytics Formula",
                    formula = "Completed % = N_completed / N_total × 100\nTasks Completed = Sum(tasks where isCompleted == true)",
                    explanation = "All numbers are computed synchronously from saved records. Historical metrics use actual event timestamps rather than retrospective estimation.",
                    dataDistinctions = "Zero values indicate measured zero activity. Unavailable metrics are omitted rather than simulated.",
                    onDismiss = { showMetricInfo = null }
                )
            }
        }
    }
}
