package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.JournalEntry

@Entity(
    tableName = "journal_entries",
    indices = [Index(value = ["goalId"])]
)
data class JournalEntity(
    @PrimaryKey val id: String,
    val goalId: String?,
    val title: String,
    val content: String,
    val timestamp: Long
) {
    fun toJournalEntry(): JournalEntry = JournalEntry(
        id = id,
        goalId = goalId,
        title = title,
        content = content,
        timestamp = timestamp
    )

    companion object {
        fun fromJournalEntry(j: JournalEntry): JournalEntity = JournalEntity(
            id = j.id,
            goalId = j.goalId,
            title = j.title,
            content = j.content,
            timestamp = j.timestamp
        )
    }
}
