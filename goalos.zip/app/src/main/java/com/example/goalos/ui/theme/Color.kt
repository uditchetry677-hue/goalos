package com.example.goalos.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.goalos.model.AccentColor

// Neutral Dark Charcoal Palette
val GoalOsDarkBackground = Color(0xFF101216)
val GoalOsDarkSurface = Color(0xFF171920)
val GoalOsDarkCard = Color(0xFF1E222A)
val GoalOsDarkCardElevated = Color(0xFF262B36)
val GoalOsDarkBorder = Color(0xFF2C323E)
val GoalOsDarkTextPrimary = Color(0xFFF3F4F6)
val GoalOsDarkTextSecondary = Color(0xFF9CA3AF)
val GoalOsDarkTextMuted = Color(0xFF6B7280)

// Neutral Light Palette
val GoalOsLightBackground = Color(0xFFF8FAFC)
val GoalOsLightSurface = Color(0xFFFFFFFF)
val GoalOsLightCard = Color(0xFFF1F5F9)
val GoalOsLightCardElevated = Color(0xFFE2E8F0)
val GoalOsLightBorder = Color(0xFFCBD5E1)
val GoalOsLightTextPrimary = Color(0xFF0F172A)
val GoalOsLightTextSecondary = Color(0xFF475569)
val GoalOsLightTextMuted = Color(0xFF94A3B8)

// Status colors
val StatusActiveColor = Color(0xFF3B82F6)    // Blue
val StatusCompletedColor = Color(0xFF10B981) // Green
val StatusPausedColor = Color(0xFFF59E0B)    // Amber
val StatusArchivedColor = Color(0xFF6B7280)  // Gray
val StatusOverdueColor = Color(0xFFEF4444)   // Red

// Priority colors
val PriorityLowColor = Color(0xFF64748B)
val PriorityMediumColor = Color(0xFF3B82F6)
val PriorityHighColor = Color(0xFFF59E0B)
val PriorityUrgentColor = Color(0xFFEF4444)

data class AccentPalette(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color
)

fun getAccentPalette(accent: AccentColor, isDark: Boolean): AccentPalette {
    return when (accent) {
        AccentColor.EMERALD -> if (isDark) {
            AccentPalette(
                primary = Color(0xFF34D399),
                onPrimary = Color(0xFF064E3B),
                primaryContainer = Color(0xFF065F46),
                onPrimaryContainer = Color(0xFFA7F3D0)
            )
        } else {
            AccentPalette(
                primary = Color(0xFF059669),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFD1FAE5),
                onPrimaryContainer = Color(0xFF065F46)
            )
        }
        AccentColor.AMBER -> if (isDark) {
            AccentPalette(
                primary = Color(0xFFFBBF24),
                onPrimary = Color(0xFF78350F),
                primaryContainer = Color(0xFF92400E),
                onPrimaryContainer = Color(0xFFFDE68A)
            )
        } else {
            AccentPalette(
                primary = Color(0xFFD97706),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFFEF3C7),
                onPrimaryContainer = Color(0xFF78350F)
            )
        }
        AccentColor.INDIGO -> if (isDark) {
            AccentPalette(
                primary = Color(0xFF818CF8),
                onPrimary = Color(0xFF1E1B4B),
                primaryContainer = Color(0xFF3730A3),
                onPrimaryContainer = Color(0xFFE0E7FF)
            )
        } else {
            AccentPalette(
                primary = Color(0xFF4F46E5),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFEEF2FF),
                onPrimaryContainer = Color(0xFF312E81)
            )
        }
        AccentColor.ROSE -> if (isDark) {
            AccentPalette(
                primary = Color(0xFFFB7185),
                onPrimary = Color(0xFF4C0519),
                primaryContainer = Color(0xFF881337),
                onPrimaryContainer = Color(0xFFFFE4E6)
            )
        } else {
            AccentPalette(
                primary = Color(0xFFE11D48),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFFFE4E6),
                onPrimaryContainer = Color(0xFF881337)
            )
        }
        AccentColor.CYAN -> if (isDark) {
            AccentPalette(
                primary = Color(0xFF22D3EE),
                onPrimary = Color(0xFF083344),
                primaryContainer = Color(0xFF155E75),
                onPrimaryContainer = Color(0xFFCFFAFE)
            )
        } else {
            AccentPalette(
                primary = Color(0xFF0891B2),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFCFFAFE),
                onPrimaryContainer = Color(0xFF164E63)
            )
        }
    }
}
