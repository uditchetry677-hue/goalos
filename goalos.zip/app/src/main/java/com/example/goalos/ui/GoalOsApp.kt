package com.example.goalos.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.Milestone
import com.example.goalos.model.NotificationType
import com.example.goalos.model.TaskItem
import com.example.goalos.ui.screens.AiAssistantSheet
import com.example.goalos.ui.screens.AnalyticsScreen
import com.example.goalos.ui.screens.CalendarScreen
import com.example.goalos.ui.screens.CreateGoalDialog
import com.example.goalos.ui.screens.CreateReminderDialog
import com.example.goalos.ui.screens.CreateTaskDialog
import com.example.goalos.ui.screens.DashboardScreen
import com.example.goalos.ui.screens.GoalDetailScreen
import com.example.goalos.ui.screens.GoalsScreen
import com.example.goalos.ui.screens.JournalScreen
import com.example.goalos.ui.screens.NotificationPreferencesDialog
import com.example.goalos.ui.screens.NotificationsCenterScreen
import com.example.goalos.ui.screens.SettingsScreen
import com.example.goalos.ui.screens.TasksScreen
import com.example.goalos.ui.theme.GoalOsTheme

enum class ScreenDestination(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    GOALS("My Goals", Icons.Default.Flag),
    TASKS("Tasks", Icons.Default.CheckCircle),
    ANALYTICS("Analytics", Icons.Default.PieChart),
    CALENDAR("Calendar", Icons.Default.CalendarMonth),
    NOTIFICATIONS("Notifications", Icons.Default.Notifications),
    JOURNAL("Journal", Icons.AutoMirrored.Filled.MenuBook),
    SETTINGS("Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalOsApp(viewModel: GoalOsViewModel) {
    val settings by viewModel.userSettings.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val allMilestones by viewModel.allMilestones.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val unreadNotifsCount by viewModel.unreadNotificationsCount.collectAsState()

    var currentScreen by remember { mutableStateOf(ScreenDestination.DASHBOARD) }
    var detailGoalId by remember { mutableStateOf<String?>(null) }

    // Dialog & Sheet States
    var showCreateGoalDialog by remember { mutableStateOf(false) }
    var goalToEdit by remember { mutableStateOf<Goal?>(null) }
    var showCreateTaskDialog by remember { mutableStateOf(false) }
    var taskGoalIdPreselection by remember { mutableStateOf<String?>(null) }
    var showAiAssistant by remember { mutableStateOf(false) }
    var aiTargetGoal by remember { mutableStateOf<Goal?>(null) }
    var showMoreSheet by remember { mutableStateOf(false) }

    // Reminder & Notification Preferences Dialog States
    var showCreateReminderDialog by remember { mutableStateOf(false) }
    var showNotificationPreferences by remember { mutableStateOf(false) }
    var reminderInitialTargetId by remember { mutableStateOf<String?>(null) }
    var reminderInitialTargetType by remember { mutableStateOf<String?>(null) }
    var reminderInitialType by remember { mutableStateOf<NotificationType?>(null) }
    var reminderInitialTitle by remember { mutableStateOf("") }
    var reminderInitialScheduledTime by remember { mutableStateOf<Long?>(null) }

    // Handle Back Press
    BackHandler(enabled = detailGoalId != null || currentScreen != ScreenDestination.DASHBOARD) {
        if (detailGoalId != null) {
            detailGoalId = null
        } else {
            currentScreen = ScreenDestination.DASHBOARD
        }
    }

    GoalOsTheme(
        themeMode = settings.themeMode,
        accentColor = settings.accentColor
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpanded = maxWidth >= 600.dp

            Row(modifier = Modifier.fillMaxSize()) {
                // Navigation Rail on Expanded Screens (Tablets / Desktop)
                if (isExpanded) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("desktop_sidebar"),
                        containerColor = MaterialTheme.colorScheme.surface,
                        header = {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 16.dp)
                            ) {
                                Text(
                                    text = "GoalOS",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    ) {
                        ScreenDestination.entries.forEach { dest ->
                            NavigationRailItem(
                                selected = currentScreen == dest && detailGoalId == null,
                                onClick = {
                                    detailGoalId = null
                                    currentScreen = dest
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.title) },
                                label = { Text(dest.title) },
                                modifier = Modifier.testTag("nav_rail_${dest.name.lowercase()}"),
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }

                // Main Content Scaffold
                Scaffold(
                    modifier = Modifier.weight(1f),
                    topBar = {
                        if (detailGoalId == null) {
                            TopAppBar(
                                title = {
                                    Text(
                                        text = currentScreen.title,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                actions = {
                                    IconButton(
                                        onClick = {
                                            detailGoalId = null
                                            currentScreen = ScreenDestination.NOTIFICATIONS
                                        },
                                        modifier = Modifier.testTag("top_notifications_btn")
                                    ) {
                                        BadgedBox(
                                            badge = {
                                                if (unreadNotifsCount > 0) {
                                                    Badge {
                                                        Text("$unreadNotifsCount")
                                                    }
                                                }
                                            }
                                        ) {
                                            Icon(
                                                if (currentScreen == ScreenDestination.NOTIFICATIONS) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                                contentDescription = "Notifications",
                                                tint = if (currentScreen == ScreenDestination.NOTIFICATIONS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            aiTargetGoal = null
                                            showAiAssistant = true
                                        },
                                        modifier = Modifier.testTag("top_ai_assistant_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.AutoAwesome,
                                            contentDescription = "AI Assistant",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.background
                                )
                            )
                        }
                    },
                    bottomBar = {
                        if (!isExpanded && detailGoalId == null) {
                            NavigationBar(
                                modifier = Modifier
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("mobile_bottom_nav"),
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                val primaryNav = listOf(
                                    ScreenDestination.DASHBOARD,
                                    ScreenDestination.GOALS,
                                    ScreenDestination.TASKS,
                                    ScreenDestination.ANALYTICS
                                )

                                primaryNav.forEach { dest ->
                                    val isSelected = currentScreen == dest
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { currentScreen = dest },
                                        icon = { Icon(dest.icon, contentDescription = dest.title) },
                                        label = { Text(dest.title) },
                                        modifier = Modifier.testTag("bottom_nav_${dest.name.lowercase()}"),
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                            indicatorColor = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }

                                val isMoreSelected = currentScreen in listOf(
                                    ScreenDestination.CALENDAR,
                                    ScreenDestination.JOURNAL,
                                    ScreenDestination.SETTINGS
                                )
                                NavigationBarItem(
                                    selected = isMoreSelected,
                                    onClick = { showMoreSheet = true },
                                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More") },
                                    label = { Text("More") },
                                    modifier = Modifier.testTag("bottom_nav_more"),
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (detailGoalId != null) {
                            GoalDetailScreen(
                                goalId = detailGoalId!!,
                                viewModel = viewModel,
                                onBack = { detailGoalId = null },
                                onEditGoal = { goal ->
                                    goalToEdit = goal
                                    showCreateGoalDialog = true
                                },
                                onOpenAiAssistant = { goal ->
                                    aiTargetGoal = goal
                                    showAiAssistant = true
                                },
                                onOpenAddTaskForGoal = { gid ->
                                    taskGoalIdPreselection = gid
                                    showCreateTaskDialog = true
                                },
                                onSetReminderForGoal = { g ->
                                    reminderInitialTargetId = g.id
                                    reminderInitialTargetType = "GOAL"
                                    reminderInitialType = NotificationType.GOAL_DEADLINE
                                    reminderInitialTitle = "Goal Deadline: ${g.title}"
                                    reminderInitialScheduledTime = g.targetDate
                                    showCreateReminderDialog = true
                                },
                                onSetReminderForMilestone = { m ->
                                    reminderInitialTargetId = m.id
                                    reminderInitialTargetType = "MILESTONE"
                                    reminderInitialType = NotificationType.MILESTONE_DEADLINE
                                    reminderInitialTitle = "Milestone Deadline: ${m.title}"
                                    reminderInitialScheduledTime = m.dueDate
                                    showCreateReminderDialog = true
                                },
                                onSetReminderForTask = { t ->
                                    reminderInitialTargetId = t.id
                                    reminderInitialTargetType = "TASK"
                                    reminderInitialType = NotificationType.TASK_REMINDER
                                    reminderInitialTitle = "Task: ${t.title}"
                                    reminderInitialScheduledTime = t.dueDate
                                    showCreateReminderDialog = true
                                }
                            )
                        } else {
                            when (currentScreen) {
                                ScreenDestination.DASHBOARD -> DashboardScreen(
                                    viewModel = viewModel,
                                    onNavigateToGoals = { statusFilter ->
                                        viewModel.setSelectedStatusFilter(statusFilter)
                                        currentScreen = ScreenDestination.GOALS
                                    },
                                    onNavigateToTasks = { currentScreen = ScreenDestination.TASKS },
                                    onNavigateToGoalDetail = { gid -> detailGoalId = gid },
                                    onOpenAddGoalDialog = {
                                        goalToEdit = null
                                        showCreateGoalDialog = true
                                    },
                                    onOpenAddTaskDialog = { gid ->
                                        taskGoalIdPreselection = gid
                                        showCreateTaskDialog = true
                                    }
                                )
                                ScreenDestination.GOALS -> GoalsScreen(
                                    viewModel = viewModel,
                                    onNavigateToGoalDetail = { gid -> detailGoalId = gid },
                                    onOpenAddGoalDialog = {
                                        goalToEdit = null
                                        showCreateGoalDialog = true
                                    },
                                    onOpenEditGoalDialog = { goal ->
                                        goalToEdit = goal
                                        showCreateGoalDialog = true
                                    }
                                )
                                ScreenDestination.TASKS -> TasksScreen(
                                    viewModel = viewModel,
                                    onOpenAddTaskDialog = { gid: String? ->
                                        taskGoalIdPreselection = gid
                                        showCreateTaskDialog = true
                                    },
                                    onSetReminderForTask = { t ->
                                        reminderInitialTargetId = t.id
                                        reminderInitialTargetType = "TASK"
                                        reminderInitialType = NotificationType.TASK_REMINDER
                                        reminderInitialTitle = "Task: ${t.title}"
                                        reminderInitialScheduledTime = t.dueDate
                                        showCreateReminderDialog = true
                                    }
                                )
                                ScreenDestination.ANALYTICS -> AnalyticsScreen(
                                    viewModel = viewModel,
                                    onNavigateToGoals = { statusFilter ->
                                        viewModel.setSelectedStatusFilter(statusFilter)
                                        currentScreen = ScreenDestination.GOALS
                                    }
                                )
                                ScreenDestination.CALENDAR -> CalendarScreen(
                                    viewModel = viewModel,
                                    onNavigateToGoalDetail = { gid -> detailGoalId = gid },
                                    onOpenAddTask = { gid ->
                                        taskGoalIdPreselection = gid
                                        showCreateTaskDialog = true
                                    }
                                )
                                ScreenDestination.NOTIFICATIONS -> NotificationsCenterScreen(
                                    viewModel = viewModel,
                                    onNavigateToGoalDetail = { gid -> detailGoalId = gid },
                                    onNavigateToTasks = { currentScreen = ScreenDestination.TASKS },
                                    onOpenCreateReminder = {
                                        reminderInitialTargetId = null
                                        reminderInitialTargetType = null
                                        reminderInitialType = null
                                        reminderInitialTitle = ""
                                        reminderInitialScheduledTime = null
                                        showCreateReminderDialog = true
                                    },
                                    onOpenPreferences = { showNotificationPreferences = true }
                                )
                                ScreenDestination.JOURNAL -> JournalScreen(
                                    viewModel = viewModel
                                )
                                ScreenDestination.SETTINGS -> SettingsScreen(
                                    viewModel = viewModel,
                                    onOpenNotificationCenter = {
                                        detailGoalId = null
                                        currentScreen = ScreenDestination.NOTIFICATIONS
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // More Bottom Sheet for secondary sections
            if (showMoreSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showMoreSheet = false },
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Additional Spaces",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        val secondaryDestinations = listOf(
                            ScreenDestination.NOTIFICATIONS,
                            ScreenDestination.CALENDAR,
                            ScreenDestination.JOURNAL,
                            ScreenDestination.SETTINGS
                        )

                        secondaryDestinations.forEach { dest ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        currentScreen = dest
                                        showMoreSheet = false
                                    },
                                color = if (currentScreen == dest) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        dest.icon,
                                        contentDescription = null,
                                        tint = if (currentScreen == dest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = dest.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (currentScreen == dest) FontWeight.Bold else FontWeight.Normal,
                                        color = if (currentScreen == dest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }

            // Create/Edit Goal Dialog
            if (showCreateGoalDialog) {
                CreateGoalDialog(
                    initialGoal = goalToEdit,
                    onDismiss = {
                        showCreateGoalDialog = false
                        goalToEdit = null
                    },
                    onSave = { title, desc, cat, prio, targetDate, metricType, targetVal, unit ->
                        if (goalToEdit != null) {
                            viewModel.updateGoal(
                                goalToEdit!!.copy(
                                    title = title,
                                    description = desc,
                                    category = cat,
                                    priority = prio,
                                    targetDate = targetDate,
                                    metricType = metricType,
                                    targetValue = targetVal,
                                    unit = unit
                                )
                            )
                        } else {
                            viewModel.createGoal(
                                title = title,
                                description = desc,
                                category = cat,
                                priority = prio,
                                targetDate = targetDate,
                                metricType = metricType,
                                targetValue = targetVal,
                                unit = unit
                            )
                        }
                        showCreateGoalDialog = false
                        goalToEdit = null
                    }
                )
            }

            // Create Task Dialog
            if (showCreateTaskDialog) {
                CreateTaskDialog(
                    goals = goals,
                    preselectedGoalId = taskGoalIdPreselection,
                    onDismiss = {
                        showCreateTaskDialog = false
                        taskGoalIdPreselection = null
                    },
                    onSave = { title, desc, goalId, due, prio, duration ->
                        viewModel.createTask(
                            title = title,
                            description = desc,
                            goalId = goalId,
                            dueDate = due,
                            priority = prio,
                            durationMinutes = duration
                        )
                        showCreateTaskDialog = false
                        taskGoalIdPreselection = null
                    }
                )
            }

            // AI Assistant Sheet
            if (showAiAssistant) {
                AiAssistantSheet(
                    targetGoal = aiTargetGoal,
                    allGoals = goals,
                    viewModel = viewModel,
                    onDismiss = {
                        showAiAssistant = false
                        aiTargetGoal = null
                    }
                )
            }

            // Create Reminder Dialog
            if (showCreateReminderDialog) {
                CreateReminderDialog(
                    goals = goals,
                    tasks = allTasks,
                    milestones = allMilestones,
                    initialTargetId = reminderInitialTargetId,
                    initialTargetType = reminderInitialTargetType,
                    initialType = reminderInitialType,
                    initialTitle = reminderInitialTitle,
                    initialScheduledTime = reminderInitialScheduledTime,
                    onDismiss = {
                        showCreateReminderDialog = false
                        reminderInitialTargetId = null
                        reminderInitialTargetType = null
                        reminderInitialType = null
                        reminderInitialTitle = ""
                        reminderInitialScheduledTime = null
                    },
                    onSave = { type, title, message, targetId, targetType, scheduledTime, advanceWarningMinutes, repeatRule, isDeviceNotificationEnabled, showInAppCenter, isUrgent ->
                        viewModel.createReminder(
                            type = type,
                            title = title,
                            message = message,
                            targetId = targetId,
                            targetType = targetType,
                            scheduledTime = scheduledTime,
                            advanceWarningMinutes = advanceWarningMinutes,
                            repeatRule = repeatRule,
                            isDeviceNotificationEnabled = isDeviceNotificationEnabled,
                            showInAppCenter = showInAppCenter,
                            isUrgent = isUrgent
                        )
                        showCreateReminderDialog = false
                        reminderInitialTargetId = null
                        reminderInitialTargetType = null
                        reminderInitialType = null
                        reminderInitialTitle = ""
                        reminderInitialScheduledTime = null
                    }
                )
            }

            // Notification Preferences Dialog
            if (showNotificationPreferences) {
                NotificationPreferencesDialog(
                    viewModel = viewModel,
                    onDismiss = { showNotificationPreferences = false }
                )
            }
        }
    }
}
