package com.example.goalos.model

enum class ThemeMode(val label: String) {
    DARK("Dark"),
    LIGHT("Light"),
    SYSTEM("System")
}

enum class AccentColor(val label: String, val hex: Long) {
    EMERALD("Emerald", 0xFF10B981),
    AMBER("Electric Amber", 0xFFF59E0B),
    INDIGO("Royal Indigo", 0xFF6366F1),
    ROSE("Rose Quartz", 0xFFF43F5E),
    CYAN("Nordic Cyan", 0xFF06B6D4)
}

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentColor: AccentColor = AccentColor.EMERALD,
    val showGreetingWidget: Boolean = true,
    val showSummaryCards: Boolean = true,
    val showPieChartWidget: Boolean = true,
    val showTodayTasksWidget: Boolean = true,
    val showActiveGoalsWidget: Boolean = true,
    val showActivityChartWidget: Boolean = true,
    val showWeeklyReviewWidget: Boolean = true,
    val remindersEnabled: Boolean = false,
    val quietHoursStart: Int = 22,
    val quietHoursEnd: Int = 8,
    val weekendQuietHours: Boolean = false,
    val digestMode: Boolean = false,
    val urgentBypassQuietHours: Boolean = true,
    val timezoneId: String = java.util.TimeZone.getDefault().id,
    val retentionDays: Int = 30,
    val groupRelatedAlerts: Boolean = false
)
