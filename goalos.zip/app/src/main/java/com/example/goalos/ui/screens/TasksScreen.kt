package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.Goal
import com.example.goalos.model.Priority
import com.example.goalos.model.TaskItem
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.theme.PriorityHighColor
import com.example.goalos.ui.theme.PriorityLowColor
import com.example.goalos.ui.theme.PriorityMediumColor
import com.example.goalos.ui.theme.PriorityUrgentColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class TaskFilter(val label: String) {
    TODAY("Today's Focus"),
    ALL("All Pending"),
    UPCOMING("Upcoming"),
    UNSCHEDULED("Unscheduled"),
    COMPLETED("Completed")
}

@Composable
fun TasksScreen(
    viewModel: GoalOsViewModel,
    onOpenAddTaskDialog: (String?) -> Unit,
    onSetReminderForTask: ((TaskItem) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.allTasks.collectAsState()
    val goals by viewModel.goals.collectAsState()

    var selectedFilter by remember { mutableStateOf(TaskFilter.TODAY) }
    var focusedTask by remember { mutableStateOf<TaskItem?>(null) }
    var taskToEdit by remember { mutableStateOf<TaskItem?>(null) }
    var quickInputText by remember { mutableStateOf("") }

    val startOfToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val endOfToday = startOfToday + 86400000L - 1L

    val filteredTasks = tasks.filter { task ->
        when (selectedFilter) {
            TaskFilter.TODAY -> !task.isCompleted && task.dueDate != null && task.dueDate in startOfToday..endOfToday
            TaskFilter.ALL -> !task.isCompleted
            TaskFilter.UPCOMING -> !task.isCompleted && task.dueDate != null && task.dueDate > endOfToday
            TaskFilter.UNSCHEDULED -> !task.isCompleted && task.dueDate == null
            TaskFilter.COMPLETED -> task.isCompleted
        }
    }

    Box(modifier = modifier.fillMaxSize().testTag("tasks_screen")) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Title & Description
            item {
                Column {
                    Text(
                        text = "Daily Workspace & Tasks",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "You decide what to work on. Reschedule anytime without guilt or penalty.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Quick add bar
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = quickInputText,
                            onValueChange = { quickInputText = it },
                            placeholder = { Text("Add task to workspace...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("task_quick_add_input"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (quickInputText.isNotBlank()) {
                                    val due = if (selectedFilter == TaskFilter.TODAY) System.currentTimeMillis() else null
                                    viewModel.createTask(title = quickInputText, dueDate = due)
                                    quickInputText = ""
                                }
                            },
                            enabled = quickInputText.isNotBlank(),
                            modifier = Modifier.testTag("task_quick_add_btn")
                        ) {
                            Text("Add")
                        }
                    }
                }
            }

            // Filters
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TaskFilter.entries.forEach { filter ->
                        item {
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label) },
                                modifier = Modifier.testTag("filter_task_${filter.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Personal Single-Task Focus Mode (if active)
            focusedTask?.let { task ->
                item {
                    val linkedGoal = goals.firstOrNull { it.id == task.goalId }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                            .testTag("focus_workspace_card"),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.SelfImprovement,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Single Focus Mode",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = { focusedTask = null },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Exit Focus")
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (task.description.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = task.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (linkedGoal != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Goal: ${linkedGoal.title}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.toggleTask(task, true)
                                        focusedTask = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Done With Task")
                                }
                            }
                        }
                    }
                }
            }

            // Task List or Empty State
            if (filteredTasks.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                            .padding(24.dp)
                            .testTag("tasks_empty_state"),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = when (selectedFilter) {
                                    TaskFilter.TODAY -> "Workspace Is Clear For Today"
                                    TaskFilter.ALL -> "No Pending Tasks"
                                    TaskFilter.UPCOMING -> "No Upcoming Scheduled Tasks"
                                    TaskFilter.UNSCHEDULED -> "No Unscheduled Tasks"
                                    TaskFilter.COMPLETED -> "No Completed Tasks Yet"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tasks are practical steps for your day. Completing tasks never completes a goal automatically.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { onOpenAddTaskDialog(null) }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Task")
                            }
                        }
                    }
                }
            } else {
                items(filteredTasks, key = { it.id }) { task ->
                    val linkedGoal = goals.firstOrNull { it.id == task.goalId }
                    TaskRowCard(
                        task = task,
                        linkedGoal = linkedGoal,
                        isFocused = focusedTask?.id == task.id,
                        onToggle = { isChecked -> viewModel.toggleTask(task, isChecked) },
                        onFocus = { focusedTask = if (focusedTask?.id == task.id) null else task },
                        onEdit = { taskToEdit = task },
                        onReschedule = { newDue -> viewModel.rescheduleTask(task, newDue) },
                        onDelete = { viewModel.deleteTask(task.id) },
                        onSetReminder = { onSetReminderForTask?.invoke(task) }
                    )
                }
            }
        }

        // FAB
        FloatingActionButton(
            onClick = { onOpenAddTaskDialog(null) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("fab_add_task"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Task")
        }
    }

    // Edit Task Dialog
    taskToEdit?.let { task ->
        var editTitle by remember { mutableStateOf(task.title) }
        var editDesc by remember { mutableStateOf(task.description) }
        var editDuration by remember { mutableStateOf(task.durationMinutes?.toString() ?: "") }
        var editPriority by remember { mutableStateOf(task.priority) }

        AlertDialog(
            onDismissRequest = { taskToEdit = null },
            title = { Text("Edit Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Task Title") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editDesc,
                        onValueChange = { editDesc = it },
                        label = { Text("Description / Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editDuration,
                        onValueChange = { editDuration = it },
                        label = { Text("Custom Time Block (Minutes)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editTitle.isNotBlank()) {
                            viewModel.updateTask(
                                task.copy(
                                    title = editTitle.trim(),
                                    description = editDesc.trim(),
                                    durationMinutes = editDuration.toIntOrNull(),
                                    priority = editPriority
                                )
                            )
                            taskToEdit = null
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { taskToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun TaskRowCard(
    task: TaskItem,
    linkedGoal: Goal?,
    isFocused: Boolean,
    onToggle: (Boolean) -> Unit,
    onFocus: () -> Unit,
    onEdit: () -> Unit,
    onReschedule: (Long?) -> Unit,
    onDelete: () -> Unit,
    onSetReminder: (() -> Unit)? = null
) {
    var menuExpanded by remember { mutableStateOf(false) }

    val prioColor = when (task.priority) {
        Priority.LOW -> PriorityLowColor
        Priority.MEDIUM -> PriorityMediumColor
        Priority.HIGH -> PriorityHighColor
        Priority.URGENT -> PriorityUrgentColor
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                1.dp,
                if (isFocused) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(14.dp)
            )
            .testTag("task_item_${task.id}"),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggle(it) },
                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("task_checkbox_${task.id}")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )

                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }

                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (linkedGoal != null) {
                        Text(
                            text = linkedGoal.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            fontSize = 11.sp
                        )
                    }

                    if (task.dueDate != null) {
                        Text(
                            text = SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(task.dueDate)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    } else {
                        Text(
                            text = "Unscheduled",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )
                    }

                    if (task.durationMinutes != null) {
                        Text(
                            text = "${task.durationMinutes}m block",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Task Menu", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(if (isFocused) "Exit Focus" else "Focus On This") },
                        leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onFocus()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Schedule for Today") },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onReschedule(System.currentTimeMillis())
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Reschedule for Tomorrow") },
                        leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onReschedule(System.currentTimeMillis() + 86400000L)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Move to Unscheduled") },
                        onClick = {
                            menuExpanded = false
                            onReschedule(null)
                        }
                    )
                    if (onSetReminder != null) {
                        DropdownMenuItem(
                            text = { Text("Set Task Reminder") },
                            leadingIcon = { Icon(Icons.Default.AddAlert, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onSetReminder()
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Edit") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onEdit()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
