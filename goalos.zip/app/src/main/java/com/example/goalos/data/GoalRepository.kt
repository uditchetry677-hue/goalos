package com.example.goalos.data

import com.example.goalos.data.entity.FocusSessionEntity
import com.example.goalos.data.entity.GoalEntity
import com.example.goalos.data.entity.HistoryEventEntity
import com.example.goalos.data.entity.JournalEntity
import com.example.goalos.data.entity.MilestoneEntity
import com.example.goalos.data.entity.NotificationEntity
import com.example.goalos.data.entity.TaskEntity
import com.example.goalos.model.FocusSession
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalHistoryEvent
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.HistoryEventType
import com.example.goalos.model.JournalEntry
import com.example.goalos.model.Milestone
import com.example.goalos.model.NotificationItem
import com.example.goalos.model.RecurrenceType
import com.example.goalos.model.TaskItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.UUID

class GoalRepository(private val db: GoalDatabase) {
    private val goalDao = db.goalDao()
    private val milestoneDao = db.milestoneDao()
    private val taskDao = db.taskDao()
    private val historyEventDao = db.historyEventDao()
    private val journalDao = db.journalDao()
    private val notificationDao = db.notificationDao()
    private val focusSessionDao = db.focusSessionDao()

    val goals: Flow<List<Goal>> = goalDao.getAllGoals().map { entities ->
        entities.map { it.toGoal() }
    }

    val allMilestones: Flow<List<Milestone>> = milestoneDao.getAllMilestones().map { entities ->
        entities.map { it.toMilestone() }
    }

    val allTasks: Flow<List<TaskItem>> = taskDao.getAllTasks().map { entities ->
        entities.map { it.toTaskItem() }
    }

    val allHistoryEvents: Flow<List<GoalHistoryEvent>> = historyEventDao.getAllEvents().map { entities ->
        entities.map { it.toHistoryEvent() }
    }

    val allJournalEntries: Flow<List<JournalEntry>> = journalDao.getAllEntries().map { entities ->
        entities.map { it.toJournalEntry() }
    }

    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications().map { entities ->
        entities.map { it.toNotificationItem() }
    }

    val inAppCenterNotifications: Flow<List<NotificationItem>> = notificationDao.getInAppCenterNotifications().map { entities ->
        entities.map { it.toNotificationItem() }
    }

    val allFocusSessions: Flow<List<FocusSession>> = focusSessionDao.getAllSessions().map { entities ->
        entities.map { it.toFocusSession() }
    }

    fun observeGoal(id: String): Flow<Goal?> = goalDao.observeGoalById(id).map { it?.toGoal() }

    suspend fun getGoal(id: String): Goal? = goalDao.getGoalById(id)?.toGoal()

    fun getMilestonesForGoal(goalId: String): Flow<List<Milestone>> =
        milestoneDao.getMilestonesForGoal(goalId).map { entities -> entities.map { it.toMilestone() } }

    fun getTasksForGoal(goalId: String): Flow<List<TaskItem>> =
        taskDao.getTasksForGoal(goalId).map { entities -> entities.map { it.toTaskItem() } }

    fun getEventsForGoal(goalId: String): Flow<List<GoalHistoryEvent>> =
        historyEventDao.getEventsForGoal(goalId).map { entities -> entities.map { it.toHistoryEvent() } }

    fun getJournalForGoal(goalId: String): Flow<List<JournalEntry>> =
        journalDao.getEntriesForGoal(goalId).map { entities -> entities.map { it.toJournalEntry() } }

    suspend fun createGoal(goal: Goal): String {
        goalDao.insertGoal(GoalEntity.fromGoal(goal))
        recordHistoryEvent(
            goalId = goal.id,
            eventType = HistoryEventType.CREATED,
            oldValue = null,
            newValue = goal.status.name,
            note = "Created goal '${goal.title}'"
        )
        return goal.id
    }

    suspend fun updateGoal(goal: Goal) {
        val existing = goalDao.getGoalById(goal.id)
        goalDao.updateGoal(GoalEntity.fromGoal(goal))
        if (existing != null && existing.title != goal.title) {
            recordHistoryEvent(
                goalId = goal.id,
                eventType = HistoryEventType.EDITED,
                oldValue = existing.title,
                newValue = goal.title,
                note = "Goal renamed to '${goal.title}'"
            )
        }
    }

    suspend fun updateGoalStatus(goalId: String, newStatus: GoalStatus, note: String? = null) {
        val currentEntity = goalDao.getGoalById(goalId) ?: return
        val currentGoal = currentEntity.toGoal()
        val now = System.currentTimeMillis()

        val updatedGoal = currentGoal.copy(
            status = newStatus,
            completedAt = if (newStatus == GoalStatus.COMPLETED) now else if (currentGoal.status == GoalStatus.COMPLETED) null else currentGoal.completedAt,
            pausedAt = if (newStatus == GoalStatus.PAUSED) now else null,
            isArchived = newStatus == GoalStatus.ARCHIVED
        )
        goalDao.updateGoal(GoalEntity.fromGoal(updatedGoal))

        recordHistoryEvent(
            goalId = goalId,
            eventType = HistoryEventType.STATUS_CHANGED,
            oldValue = currentGoal.status.name,
            newValue = newStatus.name,
            note = note ?: "Status updated from ${currentGoal.status.label} to ${newStatus.label}",
            timestamp = now
        )
    }

    suspend fun updateGoalNumericProgress(goalId: String, newValue: Double, note: String? = null) {
        val currentEntity = goalDao.getGoalById(goalId) ?: return
        val currentGoal = currentEntity.toGoal()
        val oldVal = currentGoal.currentValue
        val now = System.currentTimeMillis()

        val updatedGoal = currentGoal.copy(currentValue = newValue)
        goalDao.updateGoal(GoalEntity.fromGoal(updatedGoal))

        recordHistoryEvent(
            goalId = goalId,
            eventType = HistoryEventType.PROGRESS_LOGGED,
            oldValue = "$oldVal",
            newValue = "$newValue",
            note = note ?: "Progress updated to $newValue ${currentGoal.unit}",
            timestamp = now
        )
    }

    suspend fun deleteGoal(goalId: String) {
        goalDao.deleteGoalById(goalId)
        milestoneDao.deleteMilestonesForGoal(goalId)
        historyEventDao.deleteEventsForGoal(goalId)
        journalDao.deleteEntriesForGoal(goalId)
        val tasksForGoal = taskDao.getTasksForGoal(goalId).firstOrNull() ?: emptyList()
        tasksForGoal.forEach { taskEntity ->
            taskDao.updateTask(taskEntity.copy(goalId = null))
        }
    }

    suspend fun addMilestone(milestone: Milestone) {
        milestoneDao.insertMilestone(MilestoneEntity.fromMilestone(milestone))
    }

    suspend fun toggleMilestone(milestone: Milestone, isCompleted: Boolean) {
        val now = System.currentTimeMillis()
        val updated = milestone.copy(
            isCompleted = isCompleted,
            completedAt = if (isCompleted) now else null
        )
        milestoneDao.updateMilestone(MilestoneEntity.fromMilestone(updated))

        if (isCompleted) {
            recordHistoryEvent(
                goalId = milestone.goalId,
                eventType = HistoryEventType.MILESTONE_COMPLETED,
                oldValue = null,
                newValue = milestone.title,
                note = "Milestone '${milestone.title}' reached",
                timestamp = now
            )
        }
    }

    suspend fun deleteMilestone(milestone: Milestone) {
        milestoneDao.deleteMilestone(MilestoneEntity.fromMilestone(milestone))
    }

    suspend fun createTask(task: TaskItem): String {
        taskDao.insertTask(TaskEntity.fromTaskItem(task))
        return task.id
    }

    suspend fun updateTask(task: TaskItem) {
        taskDao.updateTask(TaskEntity.fromTaskItem(task))
    }

    suspend fun toggleTask(task: TaskItem, isCompleted: Boolean): TaskItem? {
        val now = System.currentTimeMillis()
        val updated = task.copy(
            isCompleted = isCompleted,
            completedAt = if (isCompleted) now else null
        )
        taskDao.updateTask(TaskEntity.fromTaskItem(updated))

        // If completing a recurring task, schedule the next occurrence independently
        if (isCompleted && task.isRecurring) {
            val rule = task.recurrenceRule ?: return null
            val newCount = rule.occurrencesGenerated + 1
            if (rule.maxOccurrences != null && newCount >= rule.maxOccurrences) {
                return null
            }

            val nextDue = calculateNextRecurrenceDate(task.dueDate ?: now, rule)
            if (rule.endDate != null && nextDue > rule.endDate) {
                return null
            }

            val nextOccurrence = TaskItem(
                id = UUID.randomUUID().toString(),
                goalId = task.goalId,
                title = task.title,
                description = task.description,
                isCompleted = false,
                completedAt = null,
                dueDate = nextDue,
                priority = task.priority,
                durationMinutes = task.durationMinutes,
                createdAt = now,
                recurrenceRule = rule.copy(occurrencesGenerated = newCount),
                parentRecurringTaskId = task.parentRecurringTaskId ?: task.id,
                recurrenceIndex = task.recurrenceIndex + 1,
                startTimeMinutes = task.startTimeMinutes
            )
            taskDao.insertTask(TaskEntity.fromTaskItem(nextOccurrence))
            return nextOccurrence
        }
        return null
    }

    private fun calculateNextRecurrenceDate(baseDate: Long, rule: com.example.goalos.model.RecurrenceRule): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = baseDate }
        when (rule.type) {
            RecurrenceType.DAILY -> cal.add(Calendar.DAY_OF_YEAR, rule.interval.coerceAtLeast(1))
            RecurrenceType.WEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, rule.interval.coerceAtLeast(1))
            RecurrenceType.MONTHLY -> cal.add(Calendar.MONTH, rule.interval.coerceAtLeast(1))
            RecurrenceType.CUSTOM_WEEKDAYS -> {
                if (rule.daysOfWeek.isNotEmpty()) {
                    var found = false
                    for (i in 1..7) {
                        cal.add(Calendar.DAY_OF_YEAR, 1)
                        if (rule.daysOfWeek.contains(cal.get(Calendar.DAY_OF_WEEK))) {
                            found = true
                            break
                        }
                    }
                    if (!found) cal.add(Calendar.DAY_OF_YEAR, 1)
                } else {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                }
            }
            RecurrenceType.NONE -> {}
        }
        return cal.timeInMillis
    }

    suspend fun updateRecurringTaskScope(task: TaskItem, scope: String) {
        val parentId = task.parentRecurringTaskId ?: task.id
        when (scope) {
            "THIS_ONLY" -> {
                taskDao.updateTask(TaskEntity.fromTaskItem(task))
            }
            "THIS_AND_FUTURE" -> {
                val allT = taskDao.getAllTasks().firstOrNull() ?: emptyList()
                allT.filter { (it.parentRecurringTaskId == parentId || it.id == parentId) && !it.isCompleted }
                    .forEach { entity ->
                        taskDao.updateTask(
                            entity.copy(
                                title = task.title,
                                description = task.description,
                                priority = task.priority.name,
                                durationMinutes = task.durationMinutes,
                                goalId = task.goalId
                            )
                        )
                    }
            }
            "ALL" -> {
                val allT = taskDao.getAllTasks().firstOrNull() ?: emptyList()
                allT.filter { it.parentRecurringTaskId == parentId || it.id == parentId }
                    .forEach { entity ->
                        taskDao.updateTask(
                            entity.copy(
                                title = task.title,
                                description = task.description,
                                priority = task.priority.name,
                                durationMinutes = task.durationMinutes,
                                goalId = task.goalId
                            )
                        )
                    }
            }
        }
    }

    suspend fun deleteRecurringTaskScope(task: TaskItem, scope: String) {
        val parentId = task.parentRecurringTaskId ?: task.id
        when (scope) {
            "THIS_ONLY" -> {
                taskDao.deleteTaskById(task.id)
            }
            "THIS_AND_FUTURE" -> {
                val allT = taskDao.getAllTasks().firstOrNull() ?: emptyList()
                allT.filter { (it.parentRecurringTaskId == parentId || it.id == parentId) && !it.isCompleted }
                    .forEach { taskDao.deleteTaskById(it.id) }
            }
            "ALL" -> {
                // Preserves past completed history per rule 3
                val allT = taskDao.getAllTasks().firstOrNull() ?: emptyList()
                allT.filter { (it.parentRecurringTaskId == parentId || it.id == parentId) && !it.isCompleted }
                    .forEach { taskDao.deleteTaskById(it.id) }
            }
        }
    }

    suspend fun deleteTask(taskId: String) {
        taskDao.deleteTaskById(taskId)
    }

    // Notifications
    suspend fun createNotification(item: NotificationItem): String {
        notificationDao.insertNotification(NotificationEntity.fromNotificationItem(item))
        return item.id
    }

    suspend fun updateNotification(item: NotificationItem) {
        notificationDao.updateNotification(NotificationEntity.fromNotificationItem(item))
    }

    suspend fun markNotificationRead(id: String, isRead: Boolean) {
        val notif = notificationDao.getNotificationById(id) ?: return
        notificationDao.updateNotification(notif.copy(isRead = isRead))
    }

    suspend fun dismissNotification(id: String) {
        val notif = notificationDao.getNotificationById(id) ?: return
        notificationDao.updateNotification(notif.copy(isDismissed = true, isRead = true))
    }

    suspend fun clearReadNotifications() {
        notificationDao.clearReadNotifications()
    }

    suspend fun purgeOldNotifications(retentionDays: Int): Int {
        if (retentionDays <= 0) return 0
        val cutoff = System.currentTimeMillis() - (retentionDays * 86400000L)
        return notificationDao.purgeOldNotifications(cutoff)
    }

    suspend fun deleteNotification(id: String) {
        notificationDao.deleteNotificationById(id)
    }

    // Focus Sessions
    suspend fun recordFocusSession(session: FocusSession) {
        focusSessionDao.insertSession(FocusSessionEntity.fromFocusSession(session))
    }

    // Journal
    suspend fun addJournalEntry(entry: JournalEntry) {
        journalDao.insertEntry(JournalEntity.fromJournalEntry(entry))
    }

    suspend fun deleteJournalEntry(id: String) {
        journalDao.deleteEntryById(id)
    }

    suspend fun clearAllData() {
        goalDao.clearAllGoals()
        milestoneDao.clearAllMilestones()
        taskDao.clearAllTasks()
        historyEventDao.clearAllEvents()
        journalDao.clearAllEntries()
        notificationDao.clearAllNotifications()
        focusSessionDao.clearAllSessions()
    }

    suspend fun importData(
        goalsToImport: List<Goal>,
        milestonesToImport: List<Milestone>,
        tasksToImport: List<TaskItem>,
        eventsToImport: List<GoalHistoryEvent>,
        journalToImport: List<JournalEntry>,
        notificationsToImport: List<NotificationItem> = emptyList(),
        sessionsToImport: List<FocusSession> = emptyList()
    ) {
        goalDao.insertGoals(goalsToImport.map { GoalEntity.fromGoal(it) })
        milestoneDao.insertMilestones(milestonesToImport.map { MilestoneEntity.fromMilestone(it) })
        taskDao.insertTasks(tasksToImport.map { TaskEntity.fromTaskItem(it) })
        historyEventDao.insertEvents(eventsToImport.map { HistoryEventEntity.fromHistoryEvent(it) })
        journalDao.insertEntries(journalToImport.map { JournalEntity.fromJournalEntry(it) })
        notificationDao.insertNotifications(notificationsToImport.map { NotificationEntity.fromNotificationItem(it) })
        focusSessionDao.insertSessions(sessionsToImport.map { FocusSessionEntity.fromFocusSession(it) })
    }

    private suspend fun recordHistoryEvent(
        goalId: String,
        eventType: HistoryEventType,
        oldValue: String?,
        newValue: String?,
        note: String?,
        timestamp: Long = System.currentTimeMillis()
    ) {
        val event = HistoryEventEntity(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            eventType = eventType.name,
            oldValue = oldValue,
            newValue = newValue,
            note = note,
            timestamp = timestamp
        )
        historyEventDao.insertEvent(event)
    }
}
