package com.example.goalos.model

data class FocusSession(
    val id: String,
    val taskId: String? = null,
    val goalId: String? = null,
    val taskTitle: String = "Open Focus Session",
    val durationMinutes: Int,
    val actualSecondsSpent: Int,
    val completedNaturally: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String? = null
)
