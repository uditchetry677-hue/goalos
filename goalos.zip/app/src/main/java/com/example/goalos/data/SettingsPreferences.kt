package com.example.goalos.data

import android.content.Context
import android.content.SharedPreferences
import com.example.goalos.model.AccentColor
import com.example.goalos.model.ThemeMode
import com.example.goalos.model.UserSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.TimeZone

class SettingsPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("goalos_user_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun loadSettings(): UserSettings {
        val themeStr = prefs.getString("theme_mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name
        val accentStr = prefs.getString("accent_color", AccentColor.EMERALD.name) ?: AccentColor.EMERALD.name
        return UserSettings(
            themeMode = ThemeMode.entries.firstOrNull { it.name == themeStr } ?: ThemeMode.DARK,
            accentColor = AccentColor.entries.firstOrNull { it.name == accentStr } ?: AccentColor.EMERALD,
            showGreetingWidget = prefs.getBoolean("widget_greeting", true),
            showSummaryCards = prefs.getBoolean("widget_summary", true),
            showPieChartWidget = prefs.getBoolean("widget_pie", true),
            showTodayTasksWidget = prefs.getBoolean("widget_today_tasks", true),
            showActiveGoalsWidget = prefs.getBoolean("widget_active_goals", true),
            showActivityChartWidget = prefs.getBoolean("widget_activity", true),
            showWeeklyReviewWidget = prefs.getBoolean("widget_weekly_review", true),
            remindersEnabled = prefs.getBoolean("reminders_enabled", false),
            quietHoursStart = prefs.getInt("quiet_hours_start", 22),
            quietHoursEnd = prefs.getInt("quiet_hours_end", 8),
            weekendQuietHours = prefs.getBoolean("weekend_quiet_hours", false),
            digestMode = prefs.getBoolean("digest_mode", false),
            urgentBypassQuietHours = prefs.getBoolean("urgent_bypass_quiet", true),
            timezoneId = prefs.getString("timezone_id", TimeZone.getDefault().id) ?: TimeZone.getDefault().id,
            retentionDays = prefs.getInt("retention_days", 30),
            groupRelatedAlerts = prefs.getBoolean("group_related_alerts", false)
        )
    }

    fun updateThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    fun updateAccentColor(accent: AccentColor) {
        prefs.edit().putString("accent_color", accent.name).apply()
        _settings.value = _settings.value.copy(accentColor = accent)
    }

    fun updateWidgetVisibility(
        greeting: Boolean? = null,
        summary: Boolean? = null,
        pie: Boolean? = null,
        todayTasks: Boolean? = null,
        activeGoals: Boolean? = null,
        activity: Boolean? = null,
        weeklyReview: Boolean? = null
    ) {
        val current = _settings.value
        val updated = current.copy(
            showGreetingWidget = greeting ?: current.showGreetingWidget,
            showSummaryCards = summary ?: current.showSummaryCards,
            showPieChartWidget = pie ?: current.showPieChartWidget,
            showTodayTasksWidget = todayTasks ?: current.showTodayTasksWidget,
            showActiveGoalsWidget = activeGoals ?: current.showActiveGoalsWidget,
            showActivityChartWidget = activity ?: current.showActivityChartWidget,
            showWeeklyReviewWidget = weeklyReview ?: current.showWeeklyReviewWidget
        )
        prefs.edit()
            .putBoolean("widget_greeting", updated.showGreetingWidget)
            .putBoolean("widget_summary", updated.showSummaryCards)
            .putBoolean("widget_pie", updated.showPieChartWidget)
            .putBoolean("widget_today_tasks", updated.showTodayTasksWidget)
            .putBoolean("widget_active_goals", updated.showActiveGoalsWidget)
            .putBoolean("widget_activity", updated.showActivityChartWidget)
            .putBoolean("widget_weekly_review", updated.showWeeklyReviewWidget)
            .apply()
        _settings.value = updated
    }

    fun updateReminders(
        enabled: Boolean,
        startHour: Int = 22,
        endHour: Int = 8,
        weekendQuiet: Boolean = false,
        digest: Boolean = false,
        urgentBypass: Boolean = true,
        tz: String = TimeZone.getDefault().id,
        retention: Int = 30,
        groupAlerts: Boolean = false
    ) {
        prefs.edit()
            .putBoolean("reminders_enabled", enabled)
            .putInt("quiet_hours_start", startHour)
            .putInt("quiet_hours_end", endHour)
            .putBoolean("weekend_quiet_hours", weekendQuiet)
            .putBoolean("digest_mode", digest)
            .putBoolean("urgent_bypass_quiet", urgentBypass)
            .putString("timezone_id", tz)
            .putInt("retention_days", retention)
            .putBoolean("group_related_alerts", groupAlerts)
            .apply()
        _settings.value = _settings.value.copy(
            remindersEnabled = enabled,
            quietHoursStart = startHour,
            quietHoursEnd = endHour,
            weekendQuietHours = weekendQuiet,
            digestMode = digest,
            urgentBypassQuietHours = urgentBypass,
            timezoneId = tz,
            retentionDays = retention,
            groupRelatedAlerts = groupAlerts
        )
    }

    fun updateGroupRelatedAlerts(group: Boolean) {
        prefs.edit().putBoolean("group_related_alerts", group).apply()
        _settings.value = _settings.value.copy(groupRelatedAlerts = group)
    }

    fun updateRetentionDays(days: Int) {
        prefs.edit().putInt("retention_days", days).apply()
        _settings.value = _settings.value.copy(retentionDays = days)
    }
}
