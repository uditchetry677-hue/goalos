package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.MetricType
import com.example.goalos.model.Milestone
import com.example.goalos.model.Priority
import com.example.goalos.model.TaskItem
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusOverdueColor
import com.example.goalos.ui.theme.StatusPausedColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalDetailScreen(
    goalId: String,
    viewModel: GoalOsViewModel,
    onBack: () -> Unit,
    onEditGoal: (Goal) -> Unit,
    onOpenAiAssistant: (Goal) -> Unit,
    onOpenAddTaskForGoal: (String) -> Unit,
    onSetReminderForGoal: ((Goal) -> Unit)? = null,
    onSetReminderForMilestone: ((Milestone) -> Unit)? = null,
    onSetReminderForTask: ((TaskItem) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val allMilestones by viewModel.allMilestones.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val allEvents by viewModel.allHistoryEvents.collectAsState()
    val allJournal by viewModel.allJournalEntries.collectAsState()

    val goal = goals.firstOrNull { it.id == goalId }
    if (goal == null) {
        Surface(modifier = modifier.fillMaxSize()) {
            Box(contentAlignment = Alignment.Center) {
                Text("Goal not found or was deleted.")
            }
        }
        return
    }

    val milestones = allMilestones.filter { it.goalId == goalId }
    val tasks = allTasks.filter { it.goalId == goalId }
    val events = allEvents.filter { it.goalId == goalId }
    val journal = allJournal.filter { it.goalId == goalId }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Milestones & Tasks, 1: History Log, 2: Journal
    var showAddMilestoneDialog by remember { mutableStateOf(false) }
    var newMilestoneTitle by remember { mutableStateOf("") }
    var showNumericProgressDialog by remember { mutableStateOf(false) }
    var numericInputVal by remember { mutableStateOf(goal.currentValue.toString()) }
    var numericLogNote by remember { mutableStateOf("") }

    val statusColor = when (goal.status) {
        GoalStatus.ACTIVE -> StatusActiveColor
        GoalStatus.COMPLETED -> StatusCompletedColor
        GoalStatus.PAUSED -> StatusPausedColor
        GoalStatus.ARCHIVED -> StatusPausedColor
    }

    val progressFraction = when (goal.metricType) {
        MetricType.NUMERIC -> if (goal.targetValue > 0) (goal.currentValue / goal.targetValue).toFloat().coerceIn(0f, 1f) else 0f
        MetricType.SIMPLE -> if (milestones.isNotEmpty()) (milestones.count { it.isCompleted }.toFloat() / milestones.size) else 0f
        MetricType.TASKS_BASED -> if (tasks.isNotEmpty()) (tasks.count { it.isCompleted }.toFloat() / tasks.size) else 0f
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(goal.title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("goal_detail_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onSetReminderForGoal?.invoke(goal) },
                        modifier = Modifier.testTag("goal_detail_reminder_btn")
                    ) {
                        Icon(Icons.Default.AddAlert, contentDescription = "Set Goal Reminder", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { onOpenAiAssistant(goal) }, modifier = Modifier.testTag("goal_detail_ai_btn")) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Breakdown", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { onEditGoal(goal) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Goal")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("goal_detail_screen"),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = statusColor.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, statusColor)
                            ) {
                                Text(
                                    text = goal.status.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = "Category: ${goal.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = goal.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (goal.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = goal.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        // Progress bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (goal.metricType) {
                                    MetricType.NUMERIC -> "${goal.currentValue} / ${goal.targetValue} ${goal.unit}"
                                    MetricType.SIMPLE -> "${milestones.count { it.isCompleted }} / ${milestones.size} milestones"
                                    MetricType.TASKS_BASED -> "${tasks.count { it.isCompleted }} / ${tasks.size} tasks"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = String.format("%.0f%%", progressFraction * 100),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = statusColor,
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        )

                        if (goal.metricType == MetricType.NUMERIC) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    numericInputVal = goal.currentValue.toString()
                                    numericLogNote = ""
                                    showNumericProgressDialog = true
                                },
                                modifier = Modifier.align(Alignment.End),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("Log Metric Value")
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        // Quick status toggles
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (goal.status == GoalStatus.ACTIVE) {
                                Button(
                                    onClick = { viewModel.updateGoalStatus(goal.id, GoalStatus.COMPLETED) },
                                    modifier = Modifier.weight(1f).testTag("goal_detail_complete_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusCompletedColor)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Complete")
                                }
                                OutlinedButton(
                                    onClick = { viewModel.updateGoalStatus(goal.id, GoalStatus.PAUSED) },
                                    modifier = Modifier.weight(1f).testTag("goal_detail_pause_btn")
                                ) {
                                    Icon(Icons.Default.PauseCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pause")
                                }
                            } else if (goal.status == GoalStatus.PAUSED) {
                                Button(
                                    onClick = { viewModel.updateGoalStatus(goal.id, GoalStatus.ACTIVE) },
                                    modifier = Modifier.fillMaxWidth().testTag("goal_detail_resume_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusActiveColor)
                                ) {
                                    Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Resume Active")
                                }
                            } else if (goal.status == GoalStatus.COMPLETED) {
                                OutlinedButton(
                                    onClick = { viewModel.updateGoalStatus(goal.id, GoalStatus.ACTIVE) },
                                    modifier = Modifier.fillMaxWidth().testTag("goal_detail_reopen_btn")
                                ) {
                                    Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reopen Goal")
                                }
                            }
                        }
                    }
                }
            }

            // Tabs
            item {
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Milestones & Tasks") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Audit History (${events.size})") }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Journal (${journal.size})") }
                    )
                }
            }

            // Tab 0: Milestones & Tasks
            if (selectedTab == 0) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Milestones (${milestones.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = { showAddMilestoneDialog = true },
                            modifier = Modifier.testTag("add_milestone_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Milestone")
                        }
                    }
                }

                if (milestones.isEmpty()) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "No milestones created yet. Milestones help break down long-term outcomes.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(milestones, key = { it.id }) { milestone ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = milestone.isCompleted,
                                    onCheckedChange = { checked ->
                                        viewModel.toggleMilestone(milestone, checked)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = StatusCompletedColor)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = milestone.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textDecoration = if (milestone.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onSetReminderForMilestone?.invoke(milestone) },
                                    modifier = Modifier.testTag("milestone_reminder_btn_${milestone.id}")
                                ) {
                                    Icon(Icons.Default.AddAlert, contentDescription = "Set Milestone Reminder", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { viewModel.deleteMilestone(milestone) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Milestone", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Associated Tasks (${tasks.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = { onOpenAddTaskForGoal(goal.id) }) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Task")
                        }
                    }
                }

                if (tasks.isEmpty()) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "No tasks linked directly to this goal yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(tasks, key = { it.id }) { task ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = task.isCompleted,
                                    onCheckedChange = { checked ->
                                        viewModel.toggleTask(task, checked)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onSetReminderForTask?.invoke(task) },
                                    modifier = Modifier.testTag("task_reminder_btn_${task.id}")
                                ) {
                                    Icon(Icons.Default.AddAlert, contentDescription = "Set Task Reminder", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { viewModel.deleteTask(task.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Task", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // Tab 1: History Log
            if (selectedTab == 1) {
                if (events.isEmpty()) {
                    item {
                        Text("No recorded status events yet.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    items(events, key = { it.id }) { event ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = event.eventType.label,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(event.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (event.note != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = event.note,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Tab 2: Journal
            if (selectedTab == 2) {
                if (journal.isEmpty()) {
                    item {
                        Text("No journal reflections linked to this goal yet.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    items(journal, key = { it.id }) { entry ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = entry.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = entry.content,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(entry.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Milestone Dialog
    if (showAddMilestoneDialog) {
        AlertDialog(
            onDismissRequest = { showAddMilestoneDialog = false },
            title = { Text("Add Milestone") },
            text = {
                OutlinedTextField(
                    value = newMilestoneTitle,
                    onValueChange = { newMilestoneTitle = it },
                    label = { Text("Milestone Title") },
                    modifier = Modifier.fillMaxWidth().testTag("milestone_title_input"),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newMilestoneTitle.isNotBlank()) {
                            viewModel.addMilestone(goal.id, newMilestoneTitle)
                            newMilestoneTitle = ""
                            showAddMilestoneDialog = false
                        }
                    },
                    modifier = Modifier.testTag("save_milestone_btn")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMilestoneDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Numeric Progress Dialog
    if (showNumericProgressDialog) {
        AlertDialog(
            onDismissRequest = { showNumericProgressDialog = false },
            title = { Text("Update Progress (${goal.unit})") },
            text = {
                Column {
                    OutlinedTextField(
                        value = numericInputVal,
                        onValueChange = { numericInputVal = it },
                        label = { Text("Current Value (${goal.unit})") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = numericLogNote,
                        onValueChange = { numericLogNote = it },
                        label = { Text("Progress Note (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val num = numericInputVal.toDoubleOrNull() ?: goal.currentValue
                        viewModel.updateNumericProgress(goal.id, num, numericLogNote.ifBlank { null })
                        showNumericProgressDialog = false
                    }
                ) {
                    Text("Save Progress")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNumericProgressDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
