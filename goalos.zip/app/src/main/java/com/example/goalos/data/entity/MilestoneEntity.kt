package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.Milestone

@Entity(
    tableName = "milestones",
    indices = [Index(value = ["goalId"])]
)
data class MilestoneEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val title: String,
    val isCompleted: Boolean,
    val completedAt: Long?,
    val dueDate: Long?,
    val orderIndex: Int
) {
    fun toMilestone(): Milestone = Milestone(
        id = id,
        goalId = goalId,
        title = title,
        isCompleted = isCompleted,
        completedAt = completedAt,
        dueDate = dueDate,
        orderIndex = orderIndex
    )

    companion object {
        fun fromMilestone(m: Milestone): MilestoneEntity = MilestoneEntity(
            id = m.id,
            goalId = m.goalId,
            title = m.title,
            isCompleted = m.isCompleted,
            completedAt = m.completedAt,
            dueDate = m.dueDate,
            orderIndex = m.orderIndex
        )
    }
}
