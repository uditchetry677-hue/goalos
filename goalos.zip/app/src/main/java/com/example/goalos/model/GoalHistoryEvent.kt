package com.example.goalos.model

enum class HistoryEventType(val label: String) {
    CREATED("Goal Created"),
    STATUS_CHANGED("Status Changed"),
    PROGRESS_LOGGED("Progress Logged"),
    MILESTONE_COMPLETED("Milestone Completed"),
    EDITED("Goal Edited")
}

data class GoalHistoryEvent(
    val id: String,
    val goalId: String,
    val eventType: HistoryEventType,
    val oldValue: String? = null,
    val newValue: String? = null,
    val note: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
