package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.Priority
import com.example.goalos.model.RecurrenceRule
import com.example.goalos.model.RecurrenceType
import com.example.goalos.model.TaskItem

@Entity(
    tableName = "tasks",
    indices = [Index(value = ["goalId"]), Index(value = ["parentRecurringTaskId"])]
)
data class TaskEntity(
    @PrimaryKey val id: String,
    val goalId: String?,
    val title: String,
    val description: String,
    val isCompleted: Boolean,
    val completedAt: Long?,
    val dueDate: Long?,
    val priority: String,
    val durationMinutes: Int?,
    val createdAt: Long,
    val recurrenceType: String? = null,
    val recurrenceInterval: Int = 1,
    val recurrenceDays: String? = null,
    val recurrenceEndDate: Long? = null,
    val recurrenceMax: Int? = null,
    val recurrenceCount: Int = 0,
    val parentRecurringTaskId: String? = null,
    val recurrenceIndex: Int = 0,
    val startTimeMinutes: Int? = null
) {
    fun toTaskItem(): TaskItem {
        val recRule = if (!recurrenceType.isNullOrBlank() && recurrenceType != RecurrenceType.NONE.name) {
            val daysList = recurrenceDays?.split(",")?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()
            RecurrenceRule(
                type = RecurrenceType.entries.firstOrNull { it.name == recurrenceType } ?: RecurrenceType.NONE,
                interval = recurrenceInterval.coerceAtLeast(1),
                daysOfWeek = daysList,
                endDate = recurrenceEndDate,
                maxOccurrences = recurrenceMax,
                occurrencesGenerated = recurrenceCount
            )
        } else null

        return TaskItem(
            id = id,
            goalId = goalId,
            title = title,
            description = description,
            isCompleted = isCompleted,
            completedAt = completedAt,
            dueDate = dueDate,
            priority = Priority.entries.firstOrNull { it.name == priority } ?: Priority.MEDIUM,
            durationMinutes = durationMinutes,
            createdAt = createdAt,
            recurrenceRule = recRule,
            parentRecurringTaskId = parentRecurringTaskId,
            recurrenceIndex = recurrenceIndex,
            startTimeMinutes = startTimeMinutes
        )
    }

    companion object {
        fun fromTaskItem(t: TaskItem): TaskEntity {
            val rule = t.recurrenceRule
            return TaskEntity(
                id = t.id,
                goalId = t.goalId,
                title = t.title,
                description = t.description,
                isCompleted = t.isCompleted,
                completedAt = t.completedAt,
                dueDate = t.dueDate,
                priority = t.priority.name,
                durationMinutes = t.durationMinutes,
                createdAt = t.createdAt,
                recurrenceType = rule?.type?.name,
                recurrenceInterval = rule?.interval ?: 1,
                recurrenceDays = rule?.daysOfWeek?.joinToString(","),
                recurrenceEndDate = rule?.endDate,
                recurrenceMax = rule?.maxOccurrences,
                recurrenceCount = rule?.occurrencesGenerated ?: 0,
                parentRecurringTaskId = t.parentRecurringTaskId,
                recurrenceIndex = t.recurrenceIndex,
                startTimeMinutes = t.startTimeMinutes
            )
        }
    }
}
