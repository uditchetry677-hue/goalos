package com.example.goalos.model

data class JournalEntry(
    val id: String,
    val goalId: String? = null,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
