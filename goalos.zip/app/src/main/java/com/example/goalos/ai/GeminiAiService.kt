package com.example.goalos.ai

import com.example.goalos.model.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ProposedMilestone(
    var title: String,
    var targetDaysFromNow: Int? = null
)

data class ProposedTask(
    var title: String,
    var estimatedMinutes: Int? = null,
    var priority: Priority = Priority.MEDIUM
)

data class GoalPlanProposal(
    val goalTitle: String,
    val summary: String,
    val proposedMilestones: MutableList<ProposedMilestone>,
    val proposedTasks: MutableList<ProposedTask>
)

object GeminiAiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateGoalBreakdown(
        goalTitle: String,
        description: String,
        timelineDays: Int? = null,
        apiKey: String
    ): Result<GoalPlanProposal> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Intelligent heuristic fallback so the app works reliably offline or without API keys
            return@withContext Result.success(createHeuristicProposal(goalTitle, timelineDays))
        }

        try {
            val prompt = """
                You are a disciplined, practical goal architect. Break down the user's personal goal into realistic milestones and actionable first steps.
                Goal: "$goalTitle"
                Context: "$description"
                ${if (timelineDays != null) "Target timeline: $timelineDays days." else ""}
                
                Respond ONLY with a valid JSON object matching this schema:
                {
                  "summary": "Brief realistic roadmap explanation",
                  "milestones": [
                    { "title": "Milestone title", "targetDaysFromNow": 7 }
                  ],
                  "tasks": [
                    { "title": "Actionable step", "estimatedMinutes": 30, "priority": "MEDIUM" }
                  ]
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.4)
                    put("responseMimeType", "application/json")
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                // If API call fails (e.g. invalid key or network), gracefully use heuristic
                return@withContext Result.success(createHeuristicProposal(goalTitle, timelineDays))
            }

            val bodyString = response.body?.string().orEmpty()
            val parsedObj = JSONObject(bodyString)
            val candidateText = parsedObj
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            val jsonOutput = JSONObject(candidateText)
            val summary = jsonOutput.optString("summary", "Structured breakdown for: $goalTitle")
            val milestonesJson = jsonOutput.optJSONArray("milestones") ?: JSONArray()
            val tasksJson = jsonOutput.optJSONArray("tasks") ?: JSONArray()

            val milestones = mutableListOf<ProposedMilestone>()
            for (i in 0 until milestonesJson.length()) {
                val m = milestonesJson.getJSONObject(i)
                milestones.add(
                    ProposedMilestone(
                        title = m.optString("title", "Milestone ${i + 1}"),
                        targetDaysFromNow = if (m.has("targetDaysFromNow")) m.getInt("targetDaysFromNow") else null
                    )
                )
            }

            val tasks = mutableListOf<ProposedTask>()
            for (i in 0 until tasksJson.length()) {
                val t = tasksJson.getJSONObject(i)
                val prioStr = t.optString("priority", "MEDIUM").uppercase()
                val prio = Priority.entries.firstOrNull { it.name == prioStr } ?: Priority.MEDIUM
                tasks.add(
                    ProposedTask(
                        title = t.optString("title", "Task ${i + 1}"),
                        estimatedMinutes = if (t.has("estimatedMinutes")) t.getInt("estimatedMinutes") else 30,
                        priority = prio
                    )
                )
            }

            Result.success(
                GoalPlanProposal(
                    goalTitle = goalTitle,
                    summary = summary,
                    proposedMilestones = milestones,
                    proposedTasks = tasks
                )
            )
        } catch (e: Exception) {
            // Graceful fallback to heuristic
            Result.success(createHeuristicProposal(goalTitle, timelineDays))
        }
    }

    private fun createHeuristicProposal(goalTitle: String, timelineDays: Int?): GoalPlanProposal {
        val days = timelineDays ?: 30
        val m1Days = (days * 0.25).toInt().coerceAtLeast(2)
        val m2Days = (days * 0.60).toInt().coerceAtLeast(5)
        val m3Days = days

        return GoalPlanProposal(
            goalTitle = goalTitle,
            summary = "Structured 3-stage roadmap designed for consistent execution without overwhelm.",
            proposedMilestones = mutableListOf(
                ProposedMilestone("Foundation: Define exact scope & prepare prerequisites", m1Days),
                ProposedMilestone("Core Execution: Complete 50% of key deliverables", m2Days),
                ProposedMilestone("Final Review & Target Achievement", m3Days)
            ),
            proposedTasks = mutableListOf(
                ProposedTask("Gather essential resources and research details", 30, Priority.HIGH),
                ProposedTask("Schedule dedicated daily focus blocks for $goalTitle", 15, Priority.MEDIUM),
                ProposedTask("Execute initial pilot or first chapter of work", 45, Priority.HIGH),
                ProposedTask("Log mid-way progress and adjust pacing if needed", 20, Priority.LOW)
            )
        )
    }
}
