package com.example.goalos.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.MetricType
import com.example.goalos.model.Priority
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.theme.PriorityHighColor
import com.example.goalos.ui.theme.PriorityLowColor
import com.example.goalos.ui.theme.PriorityMediumColor
import com.example.goalos.ui.theme.PriorityUrgentColor
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusArchivedColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusOverdueColor
import com.example.goalos.ui.theme.StatusPausedColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GoalsScreen(
    viewModel: GoalOsViewModel,
    onNavigateToGoalDetail: (String) -> Unit,
    onOpenAddGoalDialog: () -> Unit,
    onOpenEditGoalDialog: (Goal) -> Unit,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val allMilestones by viewModel.allMilestones.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsState()
    val selectedCategoryFilter by viewModel.selectedCategoryFilter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var goalToDelete by remember { mutableStateOf<Goal?>(null) }

    val distinctCategories = remember(goals) {
        goals.map { it.category }.distinct().filter { it.isNotBlank() }
    }

    // Filter logic
    val filteredGoals = goals.filter { goal ->
        val matchesStatus = when (selectedStatusFilter) {
            null -> !goal.isArchived // Default view excludes archived goals
            GoalStatus.ARCHIVED -> goal.isArchived || goal.status == GoalStatus.ARCHIVED
            else -> goal.status == selectedStatusFilter && !goal.isArchived
        }
        val matchesCategory = selectedCategoryFilter == null || goal.category.equals(selectedCategoryFilter, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() || goal.title.contains(searchQuery, ignoreCase = true) || goal.description.contains(searchQuery, ignoreCase = true)
        matchesStatus && matchesCategory && matchesSearch
    }

    Box(modifier = modifier.fillMaxSize().testTag("goals_screen")) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search your goals...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("goals_search_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Status Filter Row
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedStatusFilter == null,
                            onClick = { viewModel.setSelectedStatusFilter(null) },
                            label = { Text("All Active (${goals.count { !it.isArchived }})") },
                            modifier = Modifier.testTag("filter_chip_all")
                        )
                    }
                    GoalStatus.entries.forEach { status ->
                        val count = if (status == GoalStatus.ARCHIVED) {
                            goals.count { it.isArchived || it.status == GoalStatus.ARCHIVED }
                        } else {
                            goals.count { it.status == status && !it.isArchived }
                        }
                        item {
                            FilterChip(
                                selected = selectedStatusFilter == status,
                                onClick = {
                                    if (selectedStatusFilter == status) viewModel.setSelectedStatusFilter(null)
                                    else viewModel.setSelectedStatusFilter(status)
                                },
                                label = { Text("${status.label} ($count)") },
                                modifier = Modifier.testTag("filter_chip_${status.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Category Filter Row (if categories exist)
            if (distinctCategories.isNotEmpty()) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedCategoryFilter == null,
                                onClick = { viewModel.setSelectedCategoryFilter(null) },
                                label = { Text("All Categories") }
                            )
                        }
                        distinctCategories.forEach { cat ->
                            item {
                                FilterChip(
                                    selected = selectedCategoryFilter == cat,
                                    onClick = {
                                        if (selectedCategoryFilter == cat) viewModel.setSelectedCategoryFilter(null)
                                        else viewModel.setSelectedCategoryFilter(cat)
                                    },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                }
            }

            // Goals List or Honest Empty State
            if (filteredGoals.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                            .padding(24.dp)
                            .testTag("goals_empty_state"),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.Flag,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (goals.isEmpty()) "No Goals Defined" else "No Goals Match Filter",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (goals.isEmpty())
                                    "GoalOS gives you complete control. Create your first goal with only a title to begin."
                                else "Try clearing search or changing the selected status filter.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            if (goals.isEmpty()) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onOpenAddGoalDialog,
                                    modifier = Modifier.testTag("empty_state_add_goal_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Create Goal")
                                }
                            }
                        }
                    }
                }
            } else {
                items(filteredGoals, key = { it.id }) { goal ->
                    GoalCardItem(
                        goal = goal,
                        milestones = allMilestones.filter { it.goalId == goal.id },
                        tasks = allTasks.filter { it.goalId == goal.id },
                        onClick = { onNavigateToGoalDetail(goal.id) },
                        onEdit = { onOpenEditGoalDialog(goal) },
                        onDelete = { goalToDelete = goal },
                        onStatusChange = { newStatus ->
                            viewModel.updateGoalStatus(goal.id, newStatus)
                        }
                    )
                }
            }
        }

        // FAB to Add Goal
        FloatingActionButton(
            onClick = onOpenAddGoalDialog,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("fab_add_goal"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Goal")
        }
    }

    // Delete Confirmation Dialog
    goalToDelete?.let { goal ->
        AlertDialog(
            onDismissRequest = { goalToDelete = null },
            title = { Text("Delete Goal?") },
            text = {
                Text("Permanently delete '${goal.title}'? Milestones and history will be removed. Associated tasks will remain in your workspace as unassigned tasks.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteGoal(goal.id)
                        goalToDelete = null
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { goalToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun GoalCardItem(
    goal: Goal,
    milestones: List<com.example.goalos.model.Milestone>,
    tasks: List<com.example.goalos.model.TaskItem>,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onStatusChange: (GoalStatus) -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    val statusColor = when (goal.status) {
        GoalStatus.ACTIVE -> StatusActiveColor
        GoalStatus.COMPLETED -> StatusCompletedColor
        GoalStatus.PAUSED -> StatusPausedColor
        GoalStatus.ARCHIVED -> StatusArchivedColor
    }

    val prioColor = when (goal.priority) {
        Priority.LOW -> PriorityLowColor
        Priority.MEDIUM -> PriorityMediumColor
        Priority.HIGH -> PriorityHighColor
        Priority.URGENT -> PriorityUrgentColor
    }

    val progressFraction = when (goal.metricType) {
        MetricType.NUMERIC -> if (goal.targetValue > 0) (goal.currentValue / goal.targetValue).toFloat().coerceIn(0f, 1f) else 0f
        MetricType.SIMPLE -> if (milestones.isNotEmpty()) (milestones.count { it.isCompleted }.toFloat() / milestones.size) else 0f
        MetricType.TASKS_BASED -> if (tasks.isNotEmpty()) (tasks.count { it.isCompleted }.toFloat() / tasks.size) else 0f
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("goal_item_${goal.id}"),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Status & Category Pills, Title, Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Status Badge
                    Surface(
                        color = statusColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = goal.status.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 11.sp
                        )
                    }

                    // Category Badge
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = goal.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 11.sp
                        )
                    }
                }

                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(32.dp).testTag("goal_menu_btn_${goal.id}")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Goal Actions", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        if (goal.status == GoalStatus.ACTIVE) {
                            DropdownMenuItem(
                                text = { Text("Mark Completed") },
                                leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusCompletedColor) },
                                onClick = {
                                    menuExpanded = false
                                    onStatusChange(GoalStatus.COMPLETED)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Pause Goal") },
                                leadingIcon = { Icon(Icons.Default.PauseCircle, contentDescription = null, tint = StatusPausedColor) },
                                onClick = {
                                    menuExpanded = false
                                    onStatusChange(GoalStatus.PAUSED)
                                }
                            )
                        }
                        if (goal.status == GoalStatus.PAUSED) {
                            DropdownMenuItem(
                                text = { Text("Resume Active") },
                                leadingIcon = { Icon(Icons.Default.PlayCircle, contentDescription = null, tint = StatusActiveColor) },
                                onClick = {
                                    menuExpanded = false
                                    onStatusChange(GoalStatus.ACTIVE)
                                }
                            )
                        }
                        if (goal.status == GoalStatus.COMPLETED) {
                            DropdownMenuItem(
                                text = { Text("Reopen Goal") },
                                leadingIcon = { Icon(Icons.Default.Replay, contentDescription = null, tint = StatusActiveColor) },
                                onClick = {
                                    menuExpanded = false
                                    onStatusChange(GoalStatus.ACTIVE)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Edit Details") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (goal.isArchived) "Unarchive" else "Archive") },
                            leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onStatusChange(if (goal.isArchived) GoalStatus.ACTIVE else GoalStatus.ARCHIVED)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menuExpanded = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = goal.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (goal.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = goal.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar and Metric display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (goal.metricType) {
                        MetricType.NUMERIC -> "${goal.currentValue.toInt()} / ${goal.targetValue.toInt()} ${goal.unit}"
                        MetricType.SIMPLE -> "${milestones.count { it.isCompleted }} / ${milestones.size} milestones"
                        MetricType.TASKS_BASED -> "${tasks.count { it.isCompleted }} / ${tasks.size} tasks"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = String.format("%.0f%%", progressFraction * 100),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = statusColor,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Footer: Deadline & Priority
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (goal.targetDate != null) {
                        val dStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(goal.targetDate))
                        if (goal.isOverdue) "Overdue ($dStr)" else "Target: $dStr"
                    } else "No deadline set",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (goal.isOverdue) StatusOverdueColor else MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "Priority: ${goal.priority.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = prioColor,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
