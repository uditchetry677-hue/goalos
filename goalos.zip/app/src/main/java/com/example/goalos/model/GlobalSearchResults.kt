package com.example.goalos.model

data class GlobalSearchResults(
    val query: String = "",
    val matchingGoals: List<Goal> = emptyList(),
    val matchingTasks: List<TaskItem> = emptyList(),
    val matchingMilestones: List<Milestone> = emptyList(),
    val matchingJournal: List<JournalEntry> = emptyList(),
    val matchingNotifications: List<NotificationItem> = emptyList()
) {
    val totalCount: Int
        get() = matchingGoals.size + matchingTasks.size + matchingMilestones.size + matchingJournal.size + matchingNotifications.size

    val isEmpty: Boolean
        get() = totalCount == 0
}
