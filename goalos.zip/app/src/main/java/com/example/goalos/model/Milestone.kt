package com.example.goalos.model

data class Milestone(
    val id: String,
    val goalId: String,
    val title: String,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val dueDate: Long? = null,
    val orderIndex: Int = 0
)
