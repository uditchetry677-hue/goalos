package com.example.goalos.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.goalos.model.AccentColor
import com.example.goalos.model.ThemeMode

val LocalAppAccent = staticCompositionLocalOf { AccentColor.EMERALD }

@Composable
fun GoalOsTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    accentColor: AccentColor = AccentColor.EMERALD,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val palette = getAccentPalette(accentColor, isDark)

    val colorScheme: ColorScheme = if (isDark) {
        darkColorScheme(
            primary = palette.primary,
            onPrimary = palette.onPrimary,
            primaryContainer = palette.primaryContainer,
            onPrimaryContainer = palette.onPrimaryContainer,
            secondary = palette.primary,
            onSecondary = palette.onPrimary,
            background = GoalOsDarkBackground,
            onBackground = GoalOsDarkTextPrimary,
            surface = GoalOsDarkSurface,
            onSurface = GoalOsDarkTextPrimary,
            surfaceVariant = GoalOsDarkCard,
            onSurfaceVariant = GoalOsDarkTextSecondary,
            surfaceContainer = GoalOsDarkCardElevated,
            outline = GoalOsDarkBorder,
            outlineVariant = GoalOsDarkBorder
        )
    } else {
        lightColorScheme(
            primary = palette.primary,
            onPrimary = palette.onPrimary,
            primaryContainer = palette.primaryContainer,
            onPrimaryContainer = palette.onPrimaryContainer,
            secondary = palette.primary,
            onSecondary = palette.onPrimary,
            background = GoalOsLightBackground,
            onBackground = GoalOsLightTextPrimary,
            surface = GoalOsLightSurface,
            onSurface = GoalOsLightTextPrimary,
            surfaceVariant = GoalOsLightCard,
            onSurfaceVariant = GoalOsLightTextSecondary,
            surfaceContainer = GoalOsLightCardElevated,
            outline = GoalOsLightBorder,
            outlineVariant = GoalOsLightBorder
        )
    }

    CompositionLocalProvider(LocalAppAccent provides accentColor) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
