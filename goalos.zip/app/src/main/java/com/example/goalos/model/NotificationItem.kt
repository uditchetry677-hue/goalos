package com.example.goalos.model

enum class NotificationType(val label: String) {
    TASK_REMINDER("Task Reminder"),
    GOAL_REMINDER("Goal Reminder"),
    TASK_DEADLINE("Upcoming Task Deadline"),
    MILESTONE_DEADLINE("Upcoming Milestone Deadline"),
    GOAL_DEADLINE("Upcoming Goal Deadline"),
    CUSTOM_REMINDER("Custom Reminder"),
    DAILY_PLANNING("Daily Planning"),
    WEEKLY_REVIEW("Weekly Review")
}

data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val message: String,
    val targetId: String? = null,
    val targetType: String? = null, // "GOAL", "TASK", "MILESTONE", "CUSTOM"
    val scheduledTime: Long = System.currentTimeMillis(),
    val advanceWarningMinutes: Int = 0,
    val repeatRule: RecurrenceRule? = null,
    val isDeviceNotificationEnabled: Boolean = true,
    val showInAppCenter: Boolean = true,
    val isRead: Boolean = false,
    val isDismissed: Boolean = false,
    val deliveredAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val timezoneId: String = java.util.TimeZone.getDefault().id,
    val isUrgent: Boolean = false
)
