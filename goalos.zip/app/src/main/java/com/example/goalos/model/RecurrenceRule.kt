package com.example.goalos.model

enum class RecurrenceType(val label: String) {
    NONE("Does not repeat"),
    DAILY("Daily"),
    WEEKLY("Weekly"),
    MONTHLY("Monthly"),
    CUSTOM_WEEKDAYS("Specific Weekdays")
}

data class RecurrenceRule(
    val type: RecurrenceType = RecurrenceType.NONE,
    val interval: Int = 1,
    val daysOfWeek: List<Int> = emptyList(), // e.g. Calendar.MONDAY (2), Calendar.WEDNESDAY (4), etc.
    val endDate: Long? = null,
    val maxOccurrences: Int? = null,
    val occurrencesGenerated: Int = 0
) {
    val isRecurring: Boolean
        get() = type != RecurrenceType.NONE
}
