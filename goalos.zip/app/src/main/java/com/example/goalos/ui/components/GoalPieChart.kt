package com.example.goalos.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.model.GoalStatus
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusArchivedColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusPausedColor
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

data class PieChartSegment(
    val status: GoalStatus,
    val count: Int,
    val percentage: Double,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GoalPieChart(
    activeCount: Int,
    completedCount: Int,
    pausedCount: Int,
    archivedCount: Int = 0,
    includeArchived: Boolean = false,
    selectedStatus: GoalStatus? = null,
    onSelectStatus: (GoalStatus?) -> Unit = {},
    onAddGoalClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val totalEligible = activeCount + completedCount + pausedCount + (if (includeArchived) archivedCount else 0)

    if (totalEligible == 0) {
        // Honest empty state
        Surface(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                .testTag("pie_chart_empty_state"),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PieChart,
                    contentDescription = "Empty Pie Chart",
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Eligible Goals Yet",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Create your first goal to begin tracking live completion analytics.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAddGoalClick,
                    modifier = Modifier.testTag("empty_chart_add_goal_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Goal")
                }
            }
        }
        return
    }

    // Accurate calculation per specification
    val completedPct = (completedCount.toDouble() / totalEligible) * 100.0
    val activePct = (activeCount.toDouble() / totalEligible) * 100.0
    val pausedPct = (pausedCount.toDouble() / totalEligible) * 100.0
    val archivedPct = if (includeArchived) (archivedCount.toDouble() / totalEligible) * 100.0 else 0.0

    val segments = buildList {
        if (completedCount > 0) {
            add(PieChartSegment(GoalStatus.COMPLETED, completedCount, completedPct, StatusCompletedColor))
        }
        if (activeCount > 0) {
            add(PieChartSegment(GoalStatus.ACTIVE, activeCount, activePct, StatusActiveColor))
        }
        if (pausedCount > 0) {
            add(PieChartSegment(GoalStatus.PAUSED, pausedCount, pausedPct, StatusPausedColor))
        }
        if (includeArchived && archivedCount > 0) {
            add(PieChartSegment(GoalStatus.ARCHIVED, archivedCount, archivedPct, StatusArchivedColor))
        }
    }

    val animatedSweep = remember { Animatable(0f) }
    LaunchedEffect(totalEligible, completedCount, activeCount, pausedCount) {
        animatedSweep.snapTo(0f)
        animatedSweep.animateTo(1f, animationSpec = tween(600))
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            .testTag("goal_pie_chart_card"),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Goal Status Distribution",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$totalEligible Total",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Doughnut Canvas with Center Readout
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(200.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .size(190.dp)
                        .testTag("doughnut_canvas")
                        .pointerInput(segments, selectedStatus) {
                            detectTapGestures { offset ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val touchAngleRad = atan2(offset.y - center.y, offset.x - center.x)
                                var touchAngleDeg = Math.toDegrees(touchAngleRad.toDouble()).toFloat()
                                if (touchAngleDeg < 0) touchAngleDeg += 360f

                                // Standard start angle is -90 deg (top)
                                var normalizedDeg = (touchAngleDeg + 90f) % 360f

                                var cur = 0f
                                var tappedSegment: PieChartSegment? = null
                                for (seg in segments) {
                                    val sweep = (seg.count.toFloat() / totalEligible) * 360f
                                    if (normalizedDeg >= cur && normalizedDeg <= cur + sweep) {
                                        tappedSegment = seg
                                        break
                                    }
                                    cur += sweep
                                }

                                if (tappedSegment != null) {
                                    if (selectedStatus == tappedSegment.status) {
                                        onSelectStatus(null)
                                    } else {
                                        onSelectStatus(tappedSegment.status)
                                    }
                                } else {
                                    onSelectStatus(null)
                                }
                            }
                        }
                ) {
                    val strokeWidthNormal = 28.dp.toPx()
                    val strokeWidthSelected = 36.dp.toPx()
                    val canvasSize = size.minDimension
                    val radius = (canvasSize - strokeWidthSelected) / 2f
                    val center = Offset(size.width / 2f, size.height / 2f)

                    var startAngle = -90f
                    for (seg in segments) {
                        val sweep = (seg.count.toFloat() / totalEligible) * 360f * animatedSweep.value
                        val isSelected = selectedStatus == seg.status
                        val strokeWidth = if (isSelected) strokeWidthSelected else strokeWidthNormal

                        drawArc(
                            color = seg.color.copy(alpha = if (selectedStatus != null && !isSelected) 0.35f else 1f),
                            startAngle = startAngle,
                            sweepAngle = sweep.coerceAtLeast(1f),
                            useCenter = false,
                            topLeft = Offset(center.x - radius, center.y - radius),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                        )
                        startAngle += sweep
                    }
                }

                // Center readout
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (selectedStatus != null) {
                        val activeSegment = segments.firstOrNull { it.status == selectedStatus }
                        Text(
                            text = "${activeSegment?.count ?: 0}",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = activeSegment?.color ?: MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${selectedStatus.label} (${String.format("%.1f", activeSegment?.percentage ?: 0.0)}%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = String.format("%.0f%%", completedPct),
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (completedCount > 0) StatusCompletedColor else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Completed",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Interactive Legend Chips
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                segments.forEach { seg ->
                    val isSelected = selectedStatus == seg.status
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable {
                                if (isSelected) onSelectStatus(null) else onSelectStatus(seg.status)
                            }
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) seg.color else MaterialTheme.colorScheme.outline,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .testTag("legend_chip_${seg.status.name.lowercase()}"),
                        color = if (isSelected) seg.color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(seg.color)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${seg.status.label}: ${seg.count} (${String.format("%.1f", seg.percentage)}%)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (selectedStatus != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Showing ${selectedStatus.label} goals • Tap again to clear filter",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable { onSelectStatus(null) }
                )
            }
        }
    }
}
