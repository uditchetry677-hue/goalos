package com.example.goalos.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.goalos.ai.GeminiAiService
import com.example.goalos.ai.GoalPlanProposal
import com.example.goalos.data.GoalDatabase
import com.example.goalos.data.GoalRepository
import com.example.goalos.data.SettingsPreferences
import com.example.goalos.model.AccentColor
import com.example.goalos.model.FocusSession
import com.example.goalos.model.GlobalSearchResults
import com.example.goalos.model.Goal
import com.example.goalos.model.GoalHistoryEvent
import com.example.goalos.model.GoalStatus
import com.example.goalos.model.HistoryEventType
import com.example.goalos.model.JournalEntry
import com.example.goalos.model.MetricType
import com.example.goalos.model.Milestone
import com.example.goalos.model.NotificationItem
import com.example.goalos.model.NotificationType
import com.example.goalos.model.Priority
import com.example.goalos.model.RecurrenceRule
import com.example.goalos.model.RecurrenceType
import com.example.goalos.model.TaskItem
import com.example.goalos.model.ThemeMode
import com.example.goalos.model.UndoAction
import com.example.goalos.model.UserSettings
import com.example.goalos.notification.GoalOsNotificationManager
import com.example.goalos.ui.components.DailyActivityCount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class GoalOsViewModel(application: Application) : AndroidViewModel(application) {
    private val db = GoalDatabase.getInstance(application)
    private val repository = GoalRepository(db)
    private val settingsPreferences = SettingsPreferences(application)

    val userSettings: StateFlow<UserSettings> = settingsPreferences.settings

    val goals: StateFlow<List<Goal>> = repository.goals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMilestones: StateFlow<List<Milestone>> = repository.allMilestones
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasks: StateFlow<List<TaskItem>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHistoryEvents: StateFlow<List<GoalHistoryEvent>> = repository.allHistoryEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allJournalEntries: StateFlow<List<JournalEntry>> = repository.allJournalEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<NotificationItem>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inAppCenterNotifications: StateFlow<List<NotificationItem>> = repository.inAppCenterNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.inAppCenterNotifications
        .combine(repository.inAppCenterNotifications) { list, _ ->
            list.count { !it.isRead && !it.isDismissed }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val allFocusSessions: StateFlow<List<FocusSession>> = repository.allFocusSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state for filter selections
    private val _selectedStatusFilter = MutableStateFlow<GoalStatus?>(null)
    val selectedStatusFilter: StateFlow<GoalStatus?> = _selectedStatusFilter.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<String?>(null)
    val selectedCategoryFilter: StateFlow<String?> = _selectedCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Global Search Query
    private val _globalSearchQuery = MutableStateFlow("")
    val globalSearchQuery: StateFlow<String> = _globalSearchQuery.asStateFlow()

    init {
        viewModelScope.launch {
            if (userSettings.value.retentionDays > 0) {
                repository.purgeOldNotifications(userSettings.value.retentionDays)
            }
        }
    }

    val globalSearchResults: StateFlow<GlobalSearchResults> = combine(
        _globalSearchQuery,
        goals,
        allTasks,
        allMilestones,
        allJournalEntries,
        allNotifications
    ) { args: Array<Any> ->
        val q = args[0] as String
        @Suppress("UNCHECKED_CAST")
        val gList = args[1] as List<Goal>
        @Suppress("UNCHECKED_CAST")
        val tList = args[2] as List<TaskItem>
        @Suppress("UNCHECKED_CAST")
        val mList = args[3] as List<Milestone>
        @Suppress("UNCHECKED_CAST")
        val jList = args[4] as List<JournalEntry>
        @Suppress("UNCHECKED_CAST")
        val nList = args[5] as List<NotificationItem>

        val query = q.trim()
        if (query.isBlank()) {
            GlobalSearchResults(query = "")
        } else {
            GlobalSearchResults(
                query = query,
                matchingGoals = gList.filter { it.title.contains(query, true) || it.description.contains(query, true) },
                matchingTasks = tList.filter { it.title.contains(query, true) || it.description.contains(query, true) },
                matchingMilestones = mList.filter { it.title.contains(query, true) },
                matchingJournal = jList.filter { it.title.contains(query, true) || it.content.contains(query, true) },
                matchingNotifications = nList.filter { it.title.contains(query, true) || it.message.contains(query, true) }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GlobalSearchResults())

    // Reversible Undo State
    private val _lastUndoAction = MutableStateFlow<UndoAction?>(null)
    val lastUndoAction: StateFlow<UndoAction?> = _lastUndoAction.asStateFlow()

    // AI Proposal State
    private val _aiProposal = MutableStateFlow<GoalPlanProposal?>(null)
    val aiProposal: StateFlow<GoalPlanProposal?> = _aiProposal.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // 7-day activity derivation
    val weeklyActivity: StateFlow<List<DailyActivityCount>> = combine(allTasks, allHistoryEvents) { tasks, events ->
        val days = mutableListOf<DailyActivityCount>()
        val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
        val dateFormat = SimpleDateFormat("MMM d", Locale.getDefault())

        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startOfDay = cal.timeInMillis
            val endOfDay = startOfDay + 86400000L - 1L

            val taskCount = tasks.count {
                it.isCompleted && it.completedAt != null && it.completedAt in startOfDay..endOfDay
            }
            val goalCount = events.count {
                it.eventType == HistoryEventType.STATUS_CHANGED &&
                        it.newValue == GoalStatus.COMPLETED.name &&
                        it.timestamp in startOfDay..endOfDay
            }

            val dayLabel = if (i == 0) "Today" else dayFormat.format(Date(startOfDay))
            days.add(
                DailyActivityCount(
                    dateLabel = dateFormat.format(Date(startOfDay)),
                    dayOfWeek = dayLabel,
                    taskCompletions = taskCount,
                    goalCompletions = goalCount,
                    timestamp = startOfDay
                )
            )
        }
        days
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setGlobalSearchQuery(query: String) {
        _globalSearchQuery.value = query
    }

    fun setSelectedStatusFilter(status: GoalStatus?) {
        _selectedStatusFilter.value = status
    }

    fun setSelectedCategoryFilter(cat: String?) {
        _selectedCategoryFilter.value = cat
    }

    // CRUD Goal
    fun createGoal(
        title: String,
        description: String = "",
        category: String = "General",
        priority: Priority = Priority.MEDIUM,
        targetDate: Long? = null,
        metricType: MetricType = MetricType.SIMPLE,
        targetValue: Double = 100.0,
        unit: String = "%"
    ): String {
        val trimmedTitle = title.trim()
        val goalId = UUID.randomUUID().toString()
        val newGoal = Goal(
            id = goalId,
            title = trimmedTitle,
            description = description.trim(),
            category = category.trim().ifBlank { "General" },
            priority = priority,
            status = GoalStatus.ACTIVE,
            targetDate = targetDate,
            metricType = metricType,
            currentValue = 0.0,
            targetValue = targetValue,
            unit = unit.trim().ifBlank { "%" }
        )
        viewModelScope.launch {
            repository.createGoal(newGoal)
        }
        return goalId
    }

    fun updateGoal(goal: Goal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
        }
    }

    fun updateGoalStatus(goalId: String, newStatus: GoalStatus, note: String? = null) {
        val currentGoal = goals.value.firstOrNull { it.id == goalId }
        val prevStatus = currentGoal?.status ?: GoalStatus.ACTIVE
        viewModelScope.launch {
            repository.updateGoalStatus(goalId, newStatus, note)
            _lastUndoAction.value = UndoAction.GoalStatusChanged(goalId, prevStatus)
        }
    }

    fun updateNumericProgress(goalId: String, newValue: Double, note: String? = null) {
        viewModelScope.launch {
            repository.updateGoalNumericProgress(goalId, newValue, note)
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            repository.deleteGoal(goalId)
        }
    }

    // Milestones
    fun addMilestone(goalId: String, title: String, dueDate: Long? = null) {
        val trimmed = title.trim()
        if (trimmed.isBlank()) return
        val milestone = Milestone(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            title = trimmed,
            dueDate = dueDate
        )
        viewModelScope.launch {
            repository.addMilestone(milestone)
        }
    }

    fun toggleMilestone(milestone: Milestone, isCompleted: Boolean) {
        viewModelScope.launch {
            repository.toggleMilestone(milestone, isCompleted)
        }
    }

    fun deleteMilestone(milestone: Milestone) {
        viewModelScope.launch {
            repository.deleteMilestone(milestone)
            _lastUndoAction.value = UndoAction.MilestoneDeleted(milestone)
        }
    }

    // Tasks
    fun createTask(
        title: String,
        description: String = "",
        goalId: String? = null,
        dueDate: Long? = null,
        priority: Priority = Priority.MEDIUM,
        durationMinutes: Int? = null,
        recurrenceRule: RecurrenceRule? = null,
        startTimeMinutes: Int? = null
    ): String {
        val trimmed = title.trim()
        val id = UUID.randomUUID().toString()
        if (trimmed.isBlank()) return id
        val task = TaskItem(
            id = id,
            goalId = goalId,
            title = trimmed,
            description = description.trim(),
            dueDate = dueDate,
            priority = priority,
            durationMinutes = durationMinutes,
            recurrenceRule = recurrenceRule,
            startTimeMinutes = startTimeMinutes
        )
        viewModelScope.launch {
            repository.createTask(task)
        }
        return id
    }

    fun updateTask(task: TaskItem) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun updateRecurringTaskScope(task: TaskItem, scope: String) {
        viewModelScope.launch {
            repository.updateRecurringTaskScope(task, scope)
        }
    }

    fun deleteRecurringTaskScope(task: TaskItem, scope: String) {
        viewModelScope.launch {
            repository.deleteRecurringTaskScope(task, scope)
        }
    }

    fun toggleTask(task: TaskItem, isCompleted: Boolean) {
        viewModelScope.launch {
            val generated = repository.toggleTask(task, isCompleted)
            _lastUndoAction.value = UndoAction.TaskToggled(task, !isCompleted)
        }
    }

    fun rescheduleTask(task: TaskItem, newDueDate: Long?) {
        viewModelScope.launch {
            repository.updateTask(task.copy(dueDate = newDueDate))
        }
    }

    fun deleteTask(taskId: String) {
        val task = allTasks.value.firstOrNull { it.id == taskId }
        viewModelScope.launch {
            repository.deleteTask(taskId)
            if (task != null) {
                _lastUndoAction.value = UndoAction.TaskDeleted(task)
            }
        }
    }

    // Notifications & Reminders
    fun createReminder(
        type: NotificationType,
        title: String,
        message: String,
        targetId: String? = null,
        targetType: String? = null,
        scheduledTime: Long,
        advanceWarningMinutes: Int = 0,
        repeatRule: RecurrenceRule? = null,
        isDeviceNotificationEnabled: Boolean = true,
        showInAppCenter: Boolean = true,
        isUrgent: Boolean = false
    ) {
        val item = NotificationItem(
            id = UUID.randomUUID().toString(),
            type = type,
            title = title.trim(),
            message = message.trim(),
            targetId = targetId,
            targetType = targetType,
            scheduledTime = scheduledTime,
            advanceWarningMinutes = advanceWarningMinutes,
            repeatRule = repeatRule,
            isDeviceNotificationEnabled = isDeviceNotificationEnabled,
            showInAppCenter = showInAppCenter,
            isUrgent = isUrgent,
            timezoneId = userSettings.value.timezoneId
        )
        viewModelScope.launch {
            repository.createNotification(item)
            if (isDeviceNotificationEnabled && userSettings.value.remindersEnabled) {
                GoalOsNotificationManager.scheduleAlarmReminder(
                    getApplication(),
                    item,
                    userSettings.value.quietHoursStart,
                    userSettings.value.quietHoursEnd,
                    userSettings.value.weekendQuietHours
                )
            }
        }
    }

    fun snoozeNotification(notificationId: String, additionalMinutes: Int = 15) {
        viewModelScope.launch {
            val notif = allNotifications.value.firstOrNull { it.id == notificationId } ?: return@launch
            val snoozedTime = System.currentTimeMillis() + (additionalMinutes * 60000L)
            val updated = notif.copy(
                scheduledTime = snoozedTime,
                deliveredAt = null,
                isDismissed = false
            )
            repository.updateNotification(updated)
            if (updated.isDeviceNotificationEnabled && userSettings.value.remindersEnabled) {
                GoalOsNotificationManager.scheduleAlarmReminder(
                    getApplication(),
                    updated,
                    userSettings.value.quietHoursStart,
                    userSettings.value.quietHoursEnd,
                    userSettings.value.weekendQuietHours
                )
            }
        }
    }

    fun markNotificationRead(id: String, isRead: Boolean) {
        viewModelScope.launch {
            repository.markNotificationRead(id, isRead)
        }
    }

    fun dismissNotification(id: String) {
        viewModelScope.launch {
            repository.dismissNotification(id)
            GoalOsNotificationManager.cancelAlarmReminder(getApplication(), id)
            _lastUndoAction.value = UndoAction.NotificationDismissed(id)
        }
    }

    fun clearReadNotifications() {
        viewModelScope.launch {
            repository.clearReadNotifications()
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch {
            repository.deleteNotification(id)
            GoalOsNotificationManager.cancelAlarmReminder(getApplication(), id)
        }
    }

    fun triggerTestNotification(): Result<String> {
        return GoalOsNotificationManager.sendTestNotification(getApplication())
    }

    // Focus Sessions
    fun recordFocusSession(
        taskId: String?,
        goalId: String?,
        taskTitle: String,
        durationMinutes: Int,
        actualSecondsSpent: Int,
        completedNaturally: Boolean,
        notes: String? = null
    ) {
        val session = FocusSession(
            id = UUID.randomUUID().toString(),
            taskId = taskId,
            goalId = goalId,
            taskTitle = taskTitle.ifBlank { "Focus Session" },
            durationMinutes = durationMinutes,
            actualSecondsSpent = actualSecondsSpent,
            completedNaturally = completedNaturally,
            notes = notes
        )
        viewModelScope.launch {
            repository.recordFocusSession(session)
        }
    }

    // Undo Action Handler
    fun undoLastAction() {
        val action = _lastUndoAction.value ?: return
        viewModelScope.launch {
            when (action) {
                is UndoAction.TaskToggled -> {
                    repository.toggleTask(action.task, action.previousState)
                }
                is UndoAction.GoalStatusChanged -> {
                    repository.updateGoalStatus(action.goalId, action.previousStatus)
                }
                is UndoAction.TaskDeleted -> {
                    repository.createTask(action.task)
                }
                is UndoAction.MilestoneDeleted -> {
                    repository.addMilestone(action.milestone)
                }
                is UndoAction.NotificationDismissed -> {
                    repository.markNotificationRead(action.notificationId, false)
                }
            }
            _lastUndoAction.value = null
        }
    }

    fun clearUndo() {
        _lastUndoAction.value = null
    }

    // Journal
    fun addJournalEntry(title: String, content: String, goalId: String? = null) {
        val trimmedTitle = title.trim()
        val trimmedContent = content.trim()
        if (trimmedTitle.isBlank() && trimmedContent.isBlank()) return
        val entry = JournalEntry(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            title = trimmedTitle.ifBlank { "Daily Note" },
            content = trimmedContent
        )
        viewModelScope.launch {
            repository.addJournalEntry(entry)
        }
    }

    fun deleteJournalEntry(id: String) {
        viewModelScope.launch {
            repository.deleteJournalEntry(id)
        }
    }

    // Settings
    fun setThemeMode(mode: ThemeMode) {
        settingsPreferences.updateThemeMode(mode)
    }

    fun setAccentColor(accent: AccentColor) {
        settingsPreferences.updateAccentColor(accent)
    }

    fun setWidgetVisibility(
        greeting: Boolean? = null,
        summary: Boolean? = null,
        pie: Boolean? = null,
        todayTasks: Boolean? = null,
        activeGoals: Boolean? = null,
        activity: Boolean? = null,
        weeklyReview: Boolean? = null
    ) {
        settingsPreferences.updateWidgetVisibility(
            greeting, summary, pie, todayTasks, activeGoals, activity, weeklyReview
        )
    }

    fun setReminders(
        enabled: Boolean,
        startHour: Int = 22,
        endHour: Int = 8,
        weekendQuiet: Boolean = false,
        digest: Boolean = false,
        urgentBypass: Boolean = true,
        tz: String = java.util.TimeZone.getDefault().id,
        retention: Int = 30,
        groupAlerts: Boolean = false
    ) {
        settingsPreferences.updateReminders(enabled, startHour, endHour, weekendQuiet, digest, urgentBypass, tz, retention, groupAlerts)
    }

    fun setGroupRelatedAlerts(group: Boolean) {
        settingsPreferences.updateGroupRelatedAlerts(group)
    }

    fun setRetentionDays(days: Int) {
        settingsPreferences.updateRetentionDays(days)
    }

    fun purgeOldNotifications(retentionDays: Int) {
        viewModelScope.launch {
            repository.purgeOldNotifications(retentionDays)
        }
    }

    fun scheduleDailyPlanningReminder(hour: Int = 9, minute: Int = 0) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        createReminder(
            type = NotificationType.DAILY_PLANNING,
            title = "Daily Planning Reminder",
            message = "Take 5 minutes to select what matters today in your Daily Workspace.",
            targetId = null,
            targetType = "CUSTOM",
            scheduledTime = cal.timeInMillis,
            advanceWarningMinutes = 0,
            repeatRule = RecurrenceRule(type = RecurrenceType.DAILY),
            isDeviceNotificationEnabled = true,
            showInAppCenter = true,
            isUrgent = false
        )
    }

    fun scheduleWeeklyReviewReminder(dayOfWeek: Int = Calendar.SUNDAY, hour: Int = 18, minute: Int = 0) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, dayOfWeek)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.WEEK_OF_YEAR, 1)
            }
        }
        createReminder(
            type = NotificationType.WEEKLY_REVIEW,
            title = "Weekly Review Reminder",
            message = "Reflect on this week's progress and adjust your roadmap sustainably.",
            targetId = null,
            targetType = "CUSTOM",
            scheduledTime = cal.timeInMillis,
            advanceWarningMinutes = 0,
            repeatRule = RecurrenceRule(type = RecurrenceType.WEEKLY),
            isDeviceNotificationEnabled = true,
            showInAppCenter = true,
            isUrgent = false
        )
    }

    // AI Planning
    fun requestAiGoalBreakdown(goalTitle: String, description: String, timelineDays: Int?, apiKey: String) {
        _isAiLoading.value = true
        viewModelScope.launch {
            val result = GeminiAiService.generateGoalBreakdown(goalTitle, description, timelineDays, apiKey)
            _isAiLoading.value = false
            _aiProposal.value = result.getOrNull()
        }
    }

    fun clearAiProposal() {
        _aiProposal.value = null
    }

    fun applyAiProposal(goalId: String, proposal: GoalPlanProposal) {
        viewModelScope.launch {
            proposal.proposedMilestones.forEach { pm ->
                if (pm.title.isNotBlank()) {
                    val due = if (pm.targetDaysFromNow != null) {
                        System.currentTimeMillis() + (pm.targetDaysFromNow!! * 86400000L)
                    } else null
                    repository.addMilestone(
                        Milestone(
                            id = UUID.randomUUID().toString(),
                            goalId = goalId,
                            title = pm.title.trim(),
                            dueDate = due
                        )
                    )
                }
            }
            proposal.proposedTasks.forEach { pt ->
                if (pt.title.isNotBlank()) {
                    repository.createTask(
                        TaskItem(
                            id = UUID.randomUUID().toString(),
                            goalId = goalId,
                            title = pt.title.trim(),
                            priority = pt.priority,
                            durationMinutes = pt.estimatedMinutes
                        )
                    )
                }
            }
            _aiProposal.value = null
        }
    }

    // Data export & import
    fun exportDataJson(): String {
        val root = JSONObject()
        val currentGoals = goals.value
        val currentMilestones = allMilestones.value
        val currentTasks = allTasks.value
        val currentEvents = allHistoryEvents.value
        val currentJournal = allJournalEntries.value
        val currentNotifs = allNotifications.value
        val currentSessions = allFocusSessions.value

        val goalsArr = JSONArray()
        currentGoals.forEach { g ->
            goalsArr.put(JSONObject().apply {
                put("id", g.id)
                put("title", g.title)
                put("description", g.description)
                put("category", g.category)
                put("priority", g.priority.name)
                put("status", g.status.name)
                put("targetDate", g.targetDate ?: JSONObject.NULL)
                put("createdAt", g.createdAt)
                put("completedAt", g.completedAt ?: JSONObject.NULL)
                put("pausedAt", g.pausedAt ?: JSONObject.NULL)
                put("metricType", g.metricType.name)
                put("currentValue", g.currentValue)
                put("targetValue", g.targetValue)
                put("unit", g.unit)
                put("isArchived", g.isArchived)
            })
        }
        root.put("goals", goalsArr)

        val milestonesArr = JSONArray()
        currentMilestones.forEach { m ->
            milestonesArr.put(JSONObject().apply {
                put("id", m.id)
                put("goalId", m.goalId)
                put("title", m.title)
                put("isCompleted", m.isCompleted)
                put("completedAt", m.completedAt ?: JSONObject.NULL)
                put("dueDate", m.dueDate ?: JSONObject.NULL)
                put("orderIndex", m.orderIndex)
            })
        }
        root.put("milestones", milestonesArr)

        val tasksArr = JSONArray()
        currentTasks.forEach { t ->
            tasksArr.put(JSONObject().apply {
                put("id", t.id)
                put("goalId", t.goalId ?: JSONObject.NULL)
                put("title", t.title)
                put("description", t.description)
                put("isCompleted", t.isCompleted)
                put("completedAt", t.completedAt ?: JSONObject.NULL)
                put("dueDate", t.dueDate ?: JSONObject.NULL)
                put("priority", t.priority.name)
                put("durationMinutes", t.durationMinutes ?: JSONObject.NULL)
                put("createdAt", t.createdAt)
                put("recurrenceType", t.recurrenceRule?.type?.name ?: JSONObject.NULL)
                put("startTimeMinutes", t.startTimeMinutes ?: JSONObject.NULL)
            })
        }
        root.put("tasks", tasksArr)

        val eventsArr = JSONArray()
        currentEvents.forEach { e ->
            eventsArr.put(JSONObject().apply {
                put("id", e.id)
                put("goalId", e.goalId)
                put("eventType", e.eventType.name)
                put("oldValue", e.oldValue ?: JSONObject.NULL)
                put("newValue", e.newValue ?: JSONObject.NULL)
                put("note", e.note ?: JSONObject.NULL)
                put("timestamp", e.timestamp)
            })
        }
        root.put("historyEvents", eventsArr)

        val journalArr = JSONArray()
        currentJournal.forEach { j ->
            journalArr.put(JSONObject().apply {
                put("id", j.id)
                put("goalId", j.goalId ?: JSONObject.NULL)
                put("title", j.title)
                put("content", j.content)
                put("timestamp", j.timestamp)
            })
        }
        root.put("journalEntries", journalArr)

        val notifArr = JSONArray()
        currentNotifs.forEach { n ->
            notifArr.put(JSONObject().apply {
                put("id", n.id)
                put("type", n.type.name)
                put("title", n.title)
                put("message", n.message)
                put("targetId", n.targetId ?: JSONObject.NULL)
                put("targetType", n.targetType ?: JSONObject.NULL)
                put("scheduledTime", n.scheduledTime)
                put("isRead", n.isRead)
            })
        }
        root.put("notifications", notifArr)

        val sessionsArr = JSONArray()
        currentSessions.forEach { s ->
            sessionsArr.put(JSONObject().apply {
                put("id", s.id)
                put("taskTitle", s.taskTitle)
                put("durationMinutes", s.durationMinutes)
                put("actualSecondsSpent", s.actualSecondsSpent)
                put("timestamp", s.timestamp)
            })
        }
        root.put("focusSessions", sessionsArr)

        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("version", 2)

        return root.toString(2)
    }

    fun exportDataCsv(): String {
        val sb = StringBuilder()
        sb.append("Section,ID,Title,Category_Or_Goal,Status_Or_Completed,Priority,Date\n")
        goals.value.forEach { g ->
            val dateStr = g.targetDate?.let { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(it)) } ?: "No Deadline"
            sb.append("GOAL,\"${g.id}\",\"${g.title.replace("\"", "\"\"")}\",\"${g.category}\",${g.status.name},${g.priority.name},\"$dateStr\"\n")
        }
        allTasks.value.forEach { t ->
            val dateStr = t.dueDate?.let { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(it)) } ?: "Unscheduled"
            sb.append("TASK,\"${t.id}\",\"${t.title.replace("\"", "\"\"")}\",\"${t.goalId ?: "None"}\",${t.isCompleted},${t.priority.name},\"$dateStr\"\n")
        }
        allMilestones.value.forEach { m ->
            sb.append("MILESTONE,\"${m.id}\",\"${m.title.replace("\"", "\"\"")}\",\"${m.goalId}\",${m.isCompleted},NORMAL,\"-\"\n")
        }
        return sb.toString()
    }

    suspend fun importDataFromJson(jsonStr: String): Result<Int> {
        return try {
            val root = JSONObject(jsonStr)
            val goalsList = mutableListOf<Goal>()
            val milestonesList = mutableListOf<Milestone>()
            val tasksList = mutableListOf<TaskItem>()
            val eventsList = mutableListOf<GoalHistoryEvent>()
            val journalList = mutableListOf<JournalEntry>()
            val notifsList = mutableListOf<NotificationItem>()
            val sessionsList = mutableListOf<FocusSession>()

            val goalsArr = root.optJSONArray("goals")
            if (goalsArr != null) {
                for (i in 0 until goalsArr.length()) {
                    val o = goalsArr.getJSONObject(i)
                    goalsList.add(
                        Goal(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            title = o.getString("title"),
                            description = o.optString("description", ""),
                            category = o.optString("category", "General"),
                            priority = Priority.entries.firstOrNull { it.name == o.optString("priority") } ?: Priority.MEDIUM,
                            status = GoalStatus.entries.firstOrNull { it.name == o.optString("status") } ?: GoalStatus.ACTIVE,
                            targetDate = if (o.has("targetDate") && !o.isNull("targetDate")) o.getLong("targetDate") else null,
                            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                            completedAt = if (o.has("completedAt") && !o.isNull("completedAt")) o.getLong("completedAt") else null,
                            pausedAt = if (o.has("pausedAt") && !o.isNull("pausedAt")) o.getLong("pausedAt") else null,
                            metricType = MetricType.entries.firstOrNull { it.name == o.optString("metricType") } ?: MetricType.SIMPLE,
                            currentValue = o.optDouble("currentValue", 0.0),
                            targetValue = o.optDouble("targetValue", 100.0),
                            unit = o.optString("unit", "%"),
                            isArchived = o.optBoolean("isArchived", false)
                        )
                    )
                }
            }

            val tasksArr = root.optJSONArray("tasks")
            if (tasksArr != null) {
                for (i in 0 until tasksArr.length()) {
                    val o = tasksArr.getJSONObject(i)
                    val recType = o.optString("recurrenceType", null)
                    val rule = if (!recType.isNullOrBlank() && recType != "null") {
                        RecurrenceRule(type = RecurrenceType.entries.firstOrNull { it.name == recType } ?: RecurrenceType.NONE)
                    } else null

                    tasksList.add(
                        TaskItem(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            goalId = if (o.has("goalId") && !o.isNull("goalId")) o.getString("goalId") else null,
                            title = o.getString("title"),
                            description = o.optString("description", ""),
                            isCompleted = o.optBoolean("isCompleted", false),
                            completedAt = if (o.has("completedAt") && !o.isNull("completedAt")) o.getLong("completedAt") else null,
                            dueDate = if (o.has("dueDate") && !o.isNull("dueDate")) o.getLong("dueDate") else null,
                            priority = Priority.entries.firstOrNull { it.name == o.optString("priority") } ?: Priority.MEDIUM,
                            durationMinutes = if (o.has("durationMinutes") && !o.isNull("durationMinutes")) o.getInt("durationMinutes") else null,
                            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                            recurrenceRule = rule,
                            startTimeMinutes = if (o.has("startTimeMinutes") && !o.isNull("startTimeMinutes")) o.getInt("startTimeMinutes") else null
                        )
                    )
                }
            }

            val milestonesArr = root.optJSONArray("milestones")
            if (milestonesArr != null) {
                for (i in 0 until milestonesArr.length()) {
                    val o = milestonesArr.getJSONObject(i)
                    milestonesList.add(
                        Milestone(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            goalId = o.getString("goalId"),
                            title = o.getString("title"),
                            isCompleted = o.optBoolean("isCompleted", false),
                            completedAt = if (o.has("completedAt") && !o.isNull("completedAt")) o.getLong("completedAt") else null,
                            dueDate = if (o.has("dueDate") && !o.isNull("dueDate")) o.getLong("dueDate") else null,
                            orderIndex = o.optInt("orderIndex", 0)
                        )
                    )
                }
            }

            val eventsArr = root.optJSONArray("historyEvents")
            if (eventsArr != null) {
                for (i in 0 until eventsArr.length()) {
                    val o = eventsArr.getJSONObject(i)
                    eventsList.add(
                        GoalHistoryEvent(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            goalId = o.getString("goalId"),
                            eventType = HistoryEventType.entries.firstOrNull { it.name == o.optString("eventType") } ?: HistoryEventType.CREATED,
                            oldValue = if (o.has("oldValue") && !o.isNull("oldValue")) o.getString("oldValue") else null,
                            newValue = if (o.has("newValue") && !o.isNull("newValue")) o.getString("newValue") else null,
                            note = if (o.has("note") && !o.isNull("note")) o.getString("note") else null,
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            val journalArr = root.optJSONArray("journalEntries")
            if (journalArr != null) {
                for (i in 0 until journalArr.length()) {
                    val o = journalArr.getJSONObject(i)
                    journalList.add(
                        JournalEntry(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            goalId = if (o.has("goalId") && !o.isNull("goalId")) o.getString("goalId") else null,
                            title = o.getString("title"),
                            content = o.optString("content", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            repository.importData(goalsList, milestonesList, tasksList, eventsList, journalList, notifsList, sessionsList)
            Result.success(goalsList.size + tasksList.size + milestonesList.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
        }
    }
}
