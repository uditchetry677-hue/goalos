package com.example.goalos.model

sealed class UndoAction(val message: String) {
    data class TaskToggled(val task: TaskItem, val previousState: Boolean) : UndoAction("Task completion updated")
    data class GoalStatusChanged(val goalId: String, val previousStatus: GoalStatus) : UndoAction("Goal status changed")
    data class TaskDeleted(val task: TaskItem) : UndoAction("Task deleted")
    data class MilestoneDeleted(val milestone: Milestone) : UndoAction("Milestone deleted")
    data class NotificationDismissed(val notificationId: String) : UndoAction("Notification dismissed")
}
