package com.example.goalos.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.goalos.data.entity.HistoryEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryEventDao {
    @Query("SELECT * FROM history_events ORDER BY timestamp DESC")
    fun getAllEvents(): Flow<List<HistoryEventEntity>>

    @Query("SELECT * FROM history_events WHERE goalId = :goalId ORDER BY timestamp DESC")
    fun getEventsForGoal(goalId: String): Flow<List<HistoryEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: HistoryEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<HistoryEventEntity>)

    @Query("DELETE FROM history_events WHERE goalId = :goalId")
    suspend fun deleteEventsForGoal(goalId: String)

    @Query("DELETE FROM history_events")
    suspend fun clearAllEvents()
}
