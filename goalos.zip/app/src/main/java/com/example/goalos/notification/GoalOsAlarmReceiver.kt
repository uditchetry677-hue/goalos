package com.example.goalos.notification

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.goalos.data.GoalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GoalOsAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val notifId = intent.getStringExtra(GoalOsNotificationManager.EXTRA_NOTIFICATION_ID) ?: return
        val targetId = intent.getStringExtra(GoalOsNotificationManager.EXTRA_TARGET_ID)
        val targetType = intent.getStringExtra(GoalOsNotificationManager.EXTRA_TARGET_TYPE)
        val title = intent.getStringExtra(GoalOsNotificationManager.EXTRA_TITLE) ?: "GoalOS Reminder"
        val message = intent.getStringExtra(GoalOsNotificationManager.EXTRA_MESSAGE) ?: "You have a scheduled reminder."

        val db = GoalDatabase.getInstance(context)

        when (action) {
            GoalOsNotificationManager.ACTION_ALARM_TRIGGER -> {
                CoroutineScope(Dispatchers.IO).launch {
                    // Check if related task/goal was already completed (honest data integrity)
                    if (targetType == "TASK" && targetId != null) {
                        val task = db.taskDao().getTaskById(targetId)
                        if (task == null || task.isCompleted) {
                            // Do not show stale alert for already completed or deleted task
                            return@launch
                        }
                    } else if (targetType == "GOAL" && targetId != null) {
                        val goal = db.goalDao().getGoalById(targetId)
                        if (goal == null || goal.status == "COMPLETED") {
                            // Do not alert for completed goal
                            return@launch
                        }
                    } else if (targetType == "MILESTONE" && targetId != null) {
                        val milestone = db.milestoneDao().getMilestoneById(targetId)
                        if (milestone == null || milestone.isCompleted) {
                            // Do not alert for completed or deleted milestone
                            return@launch
                        }
                    }

                    // Update notification entity deliveredAt
                    val notifEntity = db.notificationDao().getNotificationById(notifId)
                    if (notifEntity != null && !notifEntity.isDismissed) {
                        db.notificationDao().updateNotification(
                            notifEntity.copy(deliveredAt = System.currentTimeMillis())
                        )
                    }

                    // Show system notification
                    showSystemNotification(context, notifId, targetId, targetType, title, message)
                }
            }

            GoalOsNotificationManager.ACTION_NOTIFICATION_COMPLETE -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(notifId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    if (targetType == "TASK" && targetId != null) {
                        val task = db.taskDao().getTaskById(targetId)
                        if (task != null) {
                            db.taskDao().updateTask(
                                task.copy(isCompleted = true, completedAt = System.currentTimeMillis())
                            )
                        }
                    } else if (targetType == "GOAL" && targetId != null) {
                        val goal = db.goalDao().getGoalById(targetId)
                        if (goal != null) {
                            db.goalDao().updateGoal(
                                goal.copy(status = "COMPLETED", completedAt = System.currentTimeMillis())
                            )
                        }
                    } else if (targetType == "MILESTONE" && targetId != null) {
                        val milestone = db.milestoneDao().getMilestoneById(targetId)
                        if (milestone != null) {
                            db.milestoneDao().updateMilestone(
                                milestone.copy(isCompleted = true, completedAt = System.currentTimeMillis())
                            )
                        }
                    }
                    val notif = db.notificationDao().getNotificationById(notifId)
                    if (notif != null) {
                        db.notificationDao().updateNotification(notif.copy(isRead = true, isDismissed = true))
                    }
                }
            }

            GoalOsNotificationManager.ACTION_NOTIFICATION_SNOOZE -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(notifId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    val notif = db.notificationDao().getNotificationById(notifId)
                    if (notif != null) {
                        val snoozedTime = System.currentTimeMillis() + (15 * 60000L) // +15 mins
                        val updated = notif.copy(
                            scheduledTime = snoozedTime,
                            deliveredAt = null,
                            isDismissed = false
                        )
                        db.notificationDao().updateNotification(updated)
                        GoalOsNotificationManager.scheduleAlarmReminder(
                            context,
                            updated.toNotificationItem()
                        )
                    }
                }
            }

            GoalOsNotificationManager.ACTION_NOTIFICATION_DISMISS -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(notifId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    val notif = db.notificationDao().getNotificationById(notifId)
                    if (notif != null) {
                        db.notificationDao().updateNotification(notif.copy(isDismissed = true, isRead = true))
                    }
                }
            }
        }
    }

    private fun showSystemNotification(
        context: Context,
        notifId: String,
        targetId: String?,
        targetType: String?,
        title: String,
        message: String
    ) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Open App intent
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("target_id", targetId)
            putExtra("target_type", targetType)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            notifId.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Complete Action Intent
        val completeIntent = Intent(context, GoalOsAlarmReceiver::class.java).apply {
            action = GoalOsNotificationManager.ACTION_NOTIFICATION_COMPLETE
            putExtra(GoalOsNotificationManager.EXTRA_NOTIFICATION_ID, notifId)
            putExtra(GoalOsNotificationManager.EXTRA_TARGET_ID, targetId)
            putExtra(GoalOsNotificationManager.EXTRA_TARGET_TYPE, targetType)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context,
            notifId.hashCode() + 1,
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze Action Intent
        val snoozeIntent = Intent(context, GoalOsAlarmReceiver::class.java).apply {
            action = GoalOsNotificationManager.ACTION_NOTIFICATION_SNOOZE
            putExtra(GoalOsNotificationManager.EXTRA_NOTIFICATION_ID, notifId)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            notifId.hashCode() + 2,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, GoalOsNotificationManager.CHANNEL_REMINDERS_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setContentIntent(openPendingIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "Complete", completePendingIntent)
            .addAction(android.R.drawable.ic_menu_recent_history, "Snooze 15m", snoozePendingIntent)
            .build()

        nm.notify(notifId.hashCode(), notification)
    }
}
