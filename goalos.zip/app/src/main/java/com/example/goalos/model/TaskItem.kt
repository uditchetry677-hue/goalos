package com.example.goalos.model

data class TaskItem(
    val id: String,
    val goalId: String? = null,
    val title: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val dueDate: Long? = null,
    val priority: Priority = Priority.MEDIUM,
    val durationMinutes: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val recurrenceRule: RecurrenceRule? = null,
    val parentRecurringTaskId: String? = null,
    val recurrenceIndex: Int = 0,
    val startTimeMinutes: Int? = null // Minutes from midnight (e.g. 9 * 60 = 540 for 09:00)
) {
    val isRecurring: Boolean
        get() = recurrenceRule != null && recurrenceRule.isRecurring
}
