package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.NotificationItem
import com.example.goalos.model.NotificationType
import com.example.goalos.model.RecurrenceRule
import com.example.goalos.model.RecurrenceType

@Entity(
    tableName = "notifications",
    indices = [Index(value = ["targetId"]), Index(value = ["scheduledTime"])]
)
data class NotificationEntity(
    @PrimaryKey val id: String,
    val type: String,
    val title: String,
    val message: String,
    val targetId: String?,
    val targetType: String?,
    val scheduledTime: Long,
    val advanceWarningMinutes: Int,
    val repeatType: String?,
    val repeatInterval: Int,
    val isDeviceNotificationEnabled: Boolean,
    val showInAppCenter: Boolean,
    val isRead: Boolean,
    val isDismissed: Boolean,
    val deliveredAt: Long?,
    val createdAt: Long,
    val timezoneId: String,
    val isUrgent: Boolean
) {
    fun toNotificationItem(): NotificationItem {
        val rule = if (!repeatType.isNullOrBlank() && repeatType != RecurrenceType.NONE.name) {
            RecurrenceRule(
                type = RecurrenceType.entries.firstOrNull { it.name == repeatType } ?: RecurrenceType.NONE,
                interval = repeatInterval
            )
        } else null

        return NotificationItem(
            id = id,
            type = NotificationType.entries.firstOrNull { it.name == type } ?: NotificationType.CUSTOM_REMINDER,
            title = title,
            message = message,
            targetId = targetId,
            targetType = targetType,
            scheduledTime = scheduledTime,
            advanceWarningMinutes = advanceWarningMinutes,
            repeatRule = rule,
            isDeviceNotificationEnabled = isDeviceNotificationEnabled,
            showInAppCenter = showInAppCenter,
            isRead = isRead,
            isDismissed = isDismissed,
            deliveredAt = deliveredAt,
            createdAt = createdAt,
            timezoneId = timezoneId,
            isUrgent = isUrgent
        )
    }

    companion object {
        fun fromNotificationItem(n: NotificationItem): NotificationEntity = NotificationEntity(
            id = n.id,
            type = n.type.name,
            title = n.title,
            message = n.message,
            targetId = n.targetId,
            targetType = n.targetType,
            scheduledTime = n.scheduledTime,
            advanceWarningMinutes = n.advanceWarningMinutes,
            repeatType = n.repeatRule?.type?.name,
            repeatInterval = n.repeatRule?.interval ?: 1,
            isDeviceNotificationEnabled = n.isDeviceNotificationEnabled,
            showInAppCenter = n.showInAppCenter,
            isRead = n.isRead,
            isDismissed = n.isDismissed,
            deliveredAt = n.deliveredAt,
            createdAt = n.createdAt,
            timezoneId = n.timezoneId,
            isUrgent = n.isUrgent
        )
    }
}
