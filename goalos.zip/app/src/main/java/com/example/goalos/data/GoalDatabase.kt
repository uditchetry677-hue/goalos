package com.example.goalos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.goalos.data.dao.FocusSessionDao
import com.example.goalos.data.dao.GoalDao
import com.example.goalos.data.dao.HistoryEventDao
import com.example.goalos.data.dao.JournalDao
import com.example.goalos.data.dao.MilestoneDao
import com.example.goalos.data.dao.NotificationDao
import com.example.goalos.data.dao.TaskDao
import com.example.goalos.data.entity.FocusSessionEntity
import com.example.goalos.data.entity.GoalEntity
import com.example.goalos.data.entity.HistoryEventEntity
import com.example.goalos.data.entity.JournalEntity
import com.example.goalos.data.entity.MilestoneEntity
import com.example.goalos.data.entity.NotificationEntity
import com.example.goalos.data.entity.TaskEntity

@Database(
    entities = [
        GoalEntity::class,
        MilestoneEntity::class,
        TaskEntity::class,
        HistoryEventEntity::class,
        JournalEntity::class,
        NotificationEntity::class,
        FocusSessionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class GoalDatabase : RoomDatabase() {
    abstract fun goalDao(): GoalDao
    abstract fun milestoneDao(): MilestoneDao
    abstract fun taskDao(): TaskDao
    abstract fun historyEventDao(): HistoryEventDao
    abstract fun journalDao(): JournalDao
    abstract fun notificationDao(): NotificationDao
    abstract fun focusSessionDao(): FocusSessionDao

    companion object {
        @Volatile
        private var INSTANCE: GoalDatabase? = null

        fun getInstance(context: Context): GoalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GoalDatabase::class.java,
                    "goalos_db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
