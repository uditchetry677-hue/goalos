package com.example.goalos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.goalos.model.FocusSession

@Entity(
    tableName = "focus_sessions",
    indices = [Index(value = ["taskId"]), Index(value = ["goalId"])]
)
data class FocusSessionEntity(
    @PrimaryKey val id: String,
    val taskId: String?,
    val goalId: String?,
    val taskTitle: String,
    val durationMinutes: Int,
    val actualSecondsSpent: Int,
    val completedNaturally: Boolean,
    val timestamp: Long,
    val notes: String?
) {
    fun toFocusSession(): FocusSession = FocusSession(
        id = id,
        taskId = taskId,
        goalId = goalId,
        taskTitle = taskTitle,
        durationMinutes = durationMinutes,
        actualSecondsSpent = actualSecondsSpent,
        completedNaturally = completedNaturally,
        timestamp = timestamp,
        notes = notes
    )

    companion object {
        fun fromFocusSession(s: FocusSession): FocusSessionEntity = FocusSessionEntity(
            id = s.id,
            taskId = s.taskId,
            goalId = s.goalId,
            taskTitle = s.taskTitle,
            durationMinutes = s.durationMinutes,
            actualSecondsSpent = s.actualSecondsSpent,
            completedNaturally = s.completedNaturally,
            timestamp = s.timestamp,
            notes = s.notes
        )
    }
}
