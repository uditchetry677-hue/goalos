package com.example.goalos.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.goalos.model.Goal
import com.example.goalos.model.Milestone
import com.example.goalos.model.NotificationType
import com.example.goalos.model.RecurrenceRule
import com.example.goalos.model.RecurrenceType
import com.example.goalos.model.TaskItem
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateReminderDialog(
    goals: List<Goal>,
    tasks: List<TaskItem>,
    milestones: List<Milestone> = emptyList(),
    initialTargetId: String? = null,
    initialTargetType: String? = null,
    initialType: NotificationType? = null,
    initialTitle: String = "",
    initialScheduledTime: Long? = null,
    onDismiss: () -> Unit,
    onSave: (
        type: NotificationType,
        title: String,
        message: String,
        targetId: String?,
        targetType: String?,
        scheduledTime: Long,
        advanceWarningMinutes: Int,
        repeatRule: RecurrenceRule?,
        isDeviceNotificationEnabled: Boolean,
        showInAppCenter: Boolean,
        isUrgent: Boolean
    ) -> Unit
) {
    val context = LocalContext.current

    var selectedType by remember {
        mutableStateOf(
            initialType ?: when (initialTargetType) {
                "TASK" -> NotificationType.TASK_REMINDER
                "GOAL" -> NotificationType.GOAL_REMINDER
                "MILESTONE" -> NotificationType.MILESTONE_DEADLINE
                else -> NotificationType.CUSTOM_REMINDER
            }
        )
    }

    var title by remember {
        mutableStateOf(
            if (initialTitle.isNotBlank()) initialTitle
            else when (initialTargetType) {
                "TASK" -> tasks.firstOrNull { it.id == initialTargetId }?.title?.let { "Task: $it" } ?: ""
                "GOAL" -> goals.firstOrNull { it.id == initialTargetId }?.title?.let { "Goal: $it" } ?: ""
                "MILESTONE" -> milestones.firstOrNull { it.id == initialTargetId }?.title?.let { "Milestone: $it" } ?: ""
                else -> ""
            }
        )
    }

    var message by remember { mutableStateOf("") }
    var selectedGoalId by remember { mutableStateOf(if (initialTargetType == "GOAL") initialTargetId else null) }
    var selectedTaskId by remember { mutableStateOf(if (initialTargetType == "TASK") initialTargetId else null) }
    var selectedMilestoneId by remember { mutableStateOf(if (initialTargetType == "MILESTONE") initialTargetId else null) }

    var advanceWarningMinutes by remember { mutableIntStateOf(0) }
    var repeatType by remember { mutableStateOf(RecurrenceType.NONE) }
    var isDeviceEnabled by remember { mutableStateOf(true) }
    var showInAppCenter by remember { mutableStateOf(true) }
    var isUrgent by remember { mutableStateOf(false) }

    var scheduledEpoch by remember {
        mutableLongStateOf(initialScheduledTime ?: (System.currentTimeMillis() + 3600000L))
    }

    var selectedTimezone by remember { mutableStateOf(TimeZone.getDefault().id) }

    var typeDropdownExpanded by remember { mutableStateOf(false) }
    var targetDropdownExpanded by remember { mutableStateOf(false) }
    var timezoneDropdownExpanded by remember { mutableStateOf(false) }

    val commonTimezones = remember {
        listOf(
            TimeZone.getDefault().id,
            "UTC",
            "America/New_York",
            "America/Los_Angeles",
            "Europe/London",
            "Europe/Paris",
            "Asia/Tokyo",
            "Asia/Singapore"
        ).distinct()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configure Reminder", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Type selector
                ExposedDropdownMenuBox(
                    expanded = typeDropdownExpanded,
                    onExpandedChange = { typeDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedType.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Notification Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("reminder_type_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = typeDropdownExpanded,
                        onDismissRequest = { typeDropdownExpanded = false }
                    ) {
                        NotificationType.entries.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.label) },
                                onClick = {
                                    selectedType = type
                                    if (type == NotificationType.DAILY_PLANNING) {
                                        title = "Daily Planning Reminder"
                                        message = "Take 5 minutes to select what matters today in your Daily Workspace."
                                        repeatType = RecurrenceType.DAILY
                                    } else if (type == NotificationType.WEEKLY_REVIEW) {
                                        title = "Weekly Review Reminder"
                                        message = "Reflect on this week's progress and adjust your roadmap sustainably."
                                        repeatType = RecurrenceType.WEEKLY
                                    }
                                    typeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Related Item Picker
                if (selectedType == NotificationType.TASK_REMINDER || selectedType == NotificationType.TASK_DEADLINE) {
                    if (tasks.isNotEmpty()) {
                        val currentTaskTitle = tasks.firstOrNull { it.id == selectedTaskId }?.title ?: "Select Task..."
                        ExposedDropdownMenuBox(
                            expanded = targetDropdownExpanded,
                            onExpandedChange = { targetDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = currentTaskTitle,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Related Task") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetDropdownExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = targetDropdownExpanded,
                                onDismissRequest = { targetDropdownExpanded = false }
                            ) {
                                tasks.forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t.title) },
                                        onClick = {
                                            selectedTaskId = t.id
                                            if (title.isBlank()) title = "Task: ${t.title}"
                                            if (t.dueDate != null) scheduledEpoch = t.dueDate
                                            targetDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else if (selectedType == NotificationType.GOAL_REMINDER || selectedType == NotificationType.GOAL_DEADLINE) {
                    if (goals.isNotEmpty()) {
                        val currentGoalTitle = goals.firstOrNull { it.id == selectedGoalId }?.title ?: "Select Goal..."
                        ExposedDropdownMenuBox(
                            expanded = targetDropdownExpanded,
                            onExpandedChange = { targetDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = currentGoalTitle,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Related Goal") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetDropdownExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = targetDropdownExpanded,
                                onDismissRequest = { targetDropdownExpanded = false }
                            ) {
                                goals.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text(g.title) },
                                        onClick = {
                                            selectedGoalId = g.id
                                            if (title.isBlank()) title = "Goal: ${g.title}"
                                            if (g.targetDate != null) scheduledEpoch = g.targetDate
                                            targetDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else if (selectedType == NotificationType.MILESTONE_DEADLINE) {
                    if (milestones.isNotEmpty()) {
                        val currentMilestoneTitle = milestones.firstOrNull { it.id == selectedMilestoneId }?.title ?: "Select Milestone..."
                        ExposedDropdownMenuBox(
                            expanded = targetDropdownExpanded,
                            onExpandedChange = { targetDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = currentMilestoneTitle,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Related Milestone") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetDropdownExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = targetDropdownExpanded,
                                onDismissRequest = { targetDropdownExpanded = false }
                            ) {
                                milestones.forEach { m ->
                                    DropdownMenuItem(
                                        text = { Text(m.title) },
                                        onClick = {
                                            selectedMilestoneId = m.id
                                            if (title.isBlank()) title = "Milestone: ${m.title}"
                                            if (m.dueDate != null) scheduledEpoch = m.dueDate
                                            targetDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Title input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Reminder Title *") },
                    placeholder = { Text("e.g. Complete sprint draft") },
                    modifier = Modifier.fillMaxWidth().testTag("reminder_input_title"),
                    singleLine = true
                )

                // Message input
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Custom Message / Note") },
                    placeholder = { Text("Any instructions or context for yourself") },
                    modifier = Modifier.fillMaxWidth().testTag("reminder_input_message"),
                    minLines = 2
                )

                // Date & Time Controls
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Trigger Date & Time", style = MaterialTheme.typography.titleSmall)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp)),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = SimpleDateFormat("EEEE, MMMM d, yyyy 'at' HH:mm", Locale.getDefault()).format(Date(scheduledEpoch)),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val cal = Calendar.getInstance().apply { timeInMillis = scheduledEpoch }
                                        DatePickerDialog(
                                            context,
                                            { _, y, m, d ->
                                                cal.set(Calendar.YEAR, y)
                                                cal.set(Calendar.MONTH, m)
                                                cal.set(Calendar.DAY_OF_MONTH, d)
                                                scheduledEpoch = cal.timeInMillis
                                            },
                                            cal.get(Calendar.YEAR),
                                            cal.get(Calendar.MONTH),
                                            cal.get(Calendar.DAY_OF_MONTH)
                                        ).show()
                                    },
                                    modifier = Modifier.weight(1f).testTag("btn_pick_date")
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Date")
                                }

                                OutlinedButton(
                                    onClick = {
                                        val cal = Calendar.getInstance().apply { timeInMillis = scheduledEpoch }
                                        TimePickerDialog(
                                            context,
                                            { _, h, m ->
                                                cal.set(Calendar.HOUR_OF_DAY, h)
                                                cal.set(Calendar.MINUTE, m)
                                                cal.set(Calendar.SECOND, 0)
                                                scheduledEpoch = cal.timeInMillis
                                            },
                                            cal.get(Calendar.HOUR_OF_DAY),
                                            cal.get(Calendar.MINUTE),
                                            true
                                        ).show()
                                    },
                                    modifier = Modifier.weight(1f).testTag("btn_pick_time")
                                ) {
                                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Time")
                                }
                            }
                        }
                    }

                    // Quick schedule chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = false,
                            onClick = { scheduledEpoch = System.currentTimeMillis() + 3600000L },
                            label = { Text("+1h") }
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val cal = Calendar.getInstance().apply {
                                    add(Calendar.DAY_OF_YEAR, 1)
                                    set(Calendar.HOUR_OF_DAY, 9)
                                    set(Calendar.MINUTE, 0)
                                }
                                scheduledEpoch = cal.timeInMillis
                            },
                            label = { Text("Tmrw 9am") }
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val cal = Calendar.getInstance().apply {
                                    add(Calendar.DAY_OF_YEAR, 7)
                                    set(Calendar.HOUR_OF_DAY, 10)
                                    set(Calendar.MINUTE, 0)
                                }
                                scheduledEpoch = cal.timeInMillis
                            },
                            label = { Text("+1 Week") }
                        )
                    }
                }

                // Timezone selection
                ExposedDropdownMenuBox(
                    expanded = timezoneDropdownExpanded,
                    onExpandedChange = { timezoneDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedTimezone,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Timezone") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = timezoneDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = timezoneDropdownExpanded,
                        onDismissRequest = { timezoneDropdownExpanded = false }
                    ) {
                        commonTimezones.forEach { tz ->
                            DropdownMenuItem(
                                text = { Text(tz) },
                                onClick = {
                                    selectedTimezone = tz
                                    timezoneDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Advance Warning
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Advance Warning Interval", style = MaterialTheme.typography.titleSmall)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            0 to "Exact",
                            15 to "15m",
                            30 to "30m",
                            60 to "1h",
                            1440 to "1d"
                        ).forEach { (mins, lbl) ->
                            FilterChip(
                                selected = advanceWarningMinutes == mins,
                                onClick = { advanceWarningMinutes = mins },
                                label = { Text(lbl) }
                            )
                        }
                    }
                }

                // Recurrence Rule
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Repeat Rule", style = MaterialTheme.typography.titleSmall)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            RecurrenceType.NONE,
                            RecurrenceType.DAILY,
                            RecurrenceType.CUSTOM_WEEKDAYS,
                            RecurrenceType.WEEKLY,
                            RecurrenceType.MONTHLY
                        ).forEach { rec ->
                            FilterChip(
                                selected = repeatType == rec,
                                onClick = { repeatType = rec },
                                label = { Text(rec.label) }
                            )
                        }
                    }
                }

                // Device Notification Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Device Notification", style = MaterialTheme.typography.bodyMedium)
                        Text("Triggers system alarm and notification drawer", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isDeviceEnabled,
                        onCheckedChange = { isDeviceEnabled = it },
                        modifier = Modifier.testTag("switch_device_notification")
                    )
                }

                // In-App Notification Center Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("In-App Notification Centre", style = MaterialTheme.typography.bodyMedium)
                        Text("Record in in-app alerts history", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = showInAppCenter,
                        onCheckedChange = { showInAppCenter = it },
                        modifier = Modifier.testTag("switch_in_app_center")
                    )
                }

                // Urgent Priority Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Urgent Priority", style = MaterialTheme.typography.bodyMedium)
                        Text("Bypasses quiet hours constraints", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isUrgent,
                        onCheckedChange = { isUrgent = it },
                        modifier = Modifier.testTag("switch_urgent_priority")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val targetId = selectedTaskId ?: selectedMilestoneId ?: selectedGoalId
                        val targetType = when {
                            selectedTaskId != null -> "TASK"
                            selectedMilestoneId != null -> "MILESTONE"
                            selectedGoalId != null -> "GOAL"
                            else -> "CUSTOM"
                        }
                        val recRule = if (repeatType != RecurrenceType.NONE) RecurrenceRule(type = repeatType) else null

                        onSave(
                            selectedType,
                            title.trim(),
                            message.trim(),
                            targetId,
                            targetType,
                            scheduledEpoch,
                            advanceWarningMinutes,
                            recRule,
                            isDeviceEnabled,
                            showInAppCenter,
                            isUrgent
                        )
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_save_reminder")
            ) {
                Text("Save Reminder")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
