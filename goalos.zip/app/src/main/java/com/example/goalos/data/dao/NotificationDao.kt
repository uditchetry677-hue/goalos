package com.example.goalos.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.goalos.data.entity.NotificationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY scheduledTime DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications WHERE id = :id")
    suspend fun getNotificationById(id: String): NotificationEntity?

    @Query("SELECT * FROM notifications WHERE isDismissed = 0 ORDER BY scheduledTime DESC")
    fun getActiveNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications WHERE showInAppCenter = 1 AND isDismissed = 0 ORDER BY scheduledTime DESC")
    fun getInAppCenterNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications WHERE scheduledTime <= :now AND deliveredAt IS NULL AND isDismissed = 0")
    suspend fun getDueUnsentNotifications(now: Long): List<NotificationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Update
    suspend fun updateNotification(notification: NotificationEntity)

    @Delete
    suspend fun deleteNotification(notification: NotificationEntity)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotificationById(id: String)

    @Query("DELETE FROM notifications WHERE isRead = 1")
    suspend fun clearReadNotifications()

    @Query("DELETE FROM notifications WHERE (isRead = 1 OR isDismissed = 1) AND scheduledTime < :cutoff")
    suspend fun purgeOldNotifications(cutoff: Long): Int

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}
