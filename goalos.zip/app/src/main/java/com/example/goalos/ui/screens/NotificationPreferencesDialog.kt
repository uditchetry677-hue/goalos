package com.example.goalos.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goalos.ui.GoalOsViewModel
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationPreferencesDialog(
    viewModel: GoalOsViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.userSettings.collectAsState()

    var remindersEnabled by remember(settings) { mutableStateOf(settings.remindersEnabled) }
    var quietStart by remember(settings) { mutableIntStateOf(settings.quietHoursStart) }
    var quietEnd by remember(settings) { mutableIntStateOf(settings.quietHoursEnd) }
    var weekendQuiet by remember(settings) { mutableStateOf(settings.weekendQuietHours) }
    var urgentBypass by remember(settings) { mutableStateOf(settings.urgentBypassQuietHours) }
    var selectedTimezone by remember(settings) { mutableStateOf(settings.timezoneId) }
    var retentionDays by remember(settings) { mutableIntStateOf(settings.retentionDays) }
    var groupAlerts by remember(settings) { mutableStateOf(settings.groupRelatedAlerts) }

    var testResultDialog by remember { mutableStateOf<String?>(null) }
    var purgeFeedback by remember { mutableStateOf<String?>(null) }
    var timezoneDropdownExpanded by remember { mutableStateOf(false) }

    val commonTimezones = remember {
        listOf(
            TimeZone.getDefault().id,
            "UTC",
            "America/New_York",
            "America/Los_Angeles",
            "Europe/London",
            "Europe/Paris",
            "Asia/Tokyo",
            "Asia/Singapore"
        ).distinct()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Notification Preferences")
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Master Enable / Disable
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp)),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enable Reminders & Notifications", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("Master toggle for scheduled device alarms and push alerts", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = remindersEnabled,
                            onCheckedChange = { remindersEnabled = it },
                            modifier = Modifier.testTag("switch_master_reminders")
                        )
                    }
                }

                // Quiet Hours Configuration
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Quiet Hours Policy", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "Reminders scheduled during quiet hours are queued until quiet hours conclude (unless marked Urgent).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(
                                    context,
                                    { _, hour, _ -> quietStart = hour },
                                    quietStart,
                                    0,
                                    true
                                ).show()
                            },
                            modifier = Modifier.weight(1f).testTag("btn_quiet_start")
                        ) {
                            Text(String.format("Start: %02d:00", quietStart), fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(
                                    context,
                                    { _, hour, _ -> quietEnd = hour },
                                    quietEnd,
                                    0,
                                    true
                                ).show()
                            },
                            modifier = Modifier.weight(1f).testTag("btn_quiet_end")
                        ) {
                            Text(String.format("End: %02d:00", quietEnd), fontSize = 12.sp)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Weekend Quiet Hours", style = MaterialTheme.typography.bodyMedium)
                            Text("Extend quiet policy across Saturday & Sunday", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = weekendQuiet,
                            onCheckedChange = { weekendQuiet = it },
                            modifier = Modifier.testTag("switch_weekend_quiet")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Urgent Priority Bypass", style = MaterialTheme.typography.bodyMedium)
                            Text("Allow urgent reminders to sound during quiet hours", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = urgentBypass,
                            onCheckedChange = { urgentBypass = it },
                            modifier = Modifier.testTag("switch_urgent_bypass")
                        )
                    }
                }

                // Timezone
                ExposedDropdownMenuBox(
                    expanded = timezoneDropdownExpanded,
                    onExpandedChange = { timezoneDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedTimezone,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Default Timezone") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = timezoneDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = timezoneDropdownExpanded,
                        onDismissRequest = { timezoneDropdownExpanded = false }
                    ) {
                        commonTimezones.forEach { tz ->
                            DropdownMenuItem(
                                text = { Text(tz) },
                                onClick = {
                                    selectedTimezone = tz
                                    timezoneDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // History Retention Controls
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("History Retention & Cleanup", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Automatically purge dismissed or read alerts after the specified interval.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            7 to "7 Days",
                            30 to "30 Days",
                            90 to "90 Days",
                            0 to "Keep All"
                        ).forEach { (days, lbl) ->
                            FilterChip(
                                selected = retentionDays == days,
                                onClick = { retentionDays = days },
                                label = { Text(lbl) }
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.purgeOldNotifications(if (retentionDays > 0) retentionDays else 30)
                            purgeFeedback = "Cleaned up old read & dismissed notification records."
                        },
                        modifier = Modifier.fillMaxWidth().testTag("btn_purge_history_now")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Purge History Now")
                    }
                }

                // Group Related Alerts Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Group Related Alerts", style = MaterialTheme.typography.bodyMedium)
                        Text("Group notifications for the same goal or task together", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = groupAlerts,
                        onCheckedChange = { groupAlerts = it },
                        modifier = Modifier.testTag("switch_group_alerts")
                    )
                }

                // Quick Setup: Daily Planning & Weekly Review Reminders
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Optional Recurring Reminders", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Set up optional consistency reminders. None are created without your explicit action.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.scheduleDailyPlanningReminder(9, 0)
                                purgeFeedback = "Configured Daily Planning Reminder for 09:00 AM."
                            },
                            modifier = Modifier.weight(1f).testTag("btn_setup_daily_planning")
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Daily 9am", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.scheduleWeeklyReviewReminder(Calendar.SUNDAY, 18, 0)
                                purgeFeedback = "Configured Weekly Review Reminder for Sunday 06:00 PM."
                            },
                            modifier = Modifier.weight(1f).testTag("btn_setup_weekly_review")
                        ) {
                            Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Weekly Sun 6pm", fontSize = 11.sp)
                        }
                    }
                }

                // Test Notification
                OutlinedButton(
                    onClick = {
                        val result = viewModel.triggerTestNotification()
                        if (result.isSuccess) {
                            testResultDialog = "Test Notification Result: ${result.getOrNull()}\n\nVerified: System channels, sound/vibrate, and foreground intent are operational."
                        } else {
                            testResultDialog = "Delivery Failed: ${result.exceptionOrNull()?.message}"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("btn_pref_test_notif")
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Send Test Notification Now")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.setReminders(
                        enabled = remindersEnabled,
                        startHour = quietStart,
                        endHour = quietEnd,
                        weekendQuiet = weekendQuiet,
                        digest = settings.digestMode,
                        urgentBypass = urgentBypass,
                        tz = selectedTimezone,
                        retention = retentionDays,
                        groupAlerts = groupAlerts
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("btn_save_preferences")
            ) {
                Text("Save Preferences")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )

    testResultDialog?.let { msg ->
        AlertDialog(
            onDismissRequest = { testResultDialog = null },
            title = { Text("Notification Report") },
            text = { Text(msg) },
            confirmButton = {
                Button(onClick = { testResultDialog = null }) { Text("OK") }
            }
        )
    }

    purgeFeedback?.let { msg ->
        AlertDialog(
            onDismissRequest = { purgeFeedback = null },
            title = { Text("GoalOS Reminders") },
            text = { Text(msg) },
            confirmButton = {
                Button(onClick = { purgeFeedback = null }) { Text("OK") }
            }
        )
    }
}
