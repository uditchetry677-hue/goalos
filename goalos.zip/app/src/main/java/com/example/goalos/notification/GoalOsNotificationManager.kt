package com.example.goalos.notification

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.goalos.model.NotificationItem
import com.example.goalos.model.NotificationType
import java.util.Calendar
import java.util.TimeZone

object GoalOsNotificationManager {
    const val CHANNEL_REMINDERS_ID = "goalos_reminders_channel"
    const val CHANNEL_URGENT_ID = "goalos_urgent_channel"

    const val ACTION_ALARM_TRIGGER = "com.example.goalos.ACTION_ALARM_TRIGGER"
    const val ACTION_NOTIFICATION_COMPLETE = "com.example.goalos.ACTION_NOTIFICATION_COMPLETE"
    const val ACTION_NOTIFICATION_SNOOZE = "com.example.goalos.ACTION_NOTIFICATION_SNOOZE"
    const val ACTION_NOTIFICATION_DISMISS = "com.example.goalos.ACTION_NOTIFICATION_DISMISS"

    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    const val EXTRA_TARGET_ID = "extra_target_id"
    const val EXTRA_TARGET_TYPE = "extra_target_type"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_MESSAGE = "extra_message"

    fun initNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val remindersChannel = NotificationChannel(
                CHANNEL_REMINDERS_ID,
                "GoalOS Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Task reminders, milestone and goal deadline alerts"
                enableVibration(true)
            }

            val urgentChannel = NotificationChannel(
                CHANNEL_URGENT_ID,
                "GoalOS Urgent Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent user-configured priority alerts"
                enableVibration(true)
            }

            nm.createNotificationChannel(remindersChannel)
            nm.createNotificationChannel(urgentChannel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isWithinQuietHours(
        startHour: Int,
        endHour: Int,
        timezoneId: String = TimeZone.getDefault().id,
        weekendQuiet: Boolean = false
    ): Boolean {
        val cal = Calendar.getInstance(TimeZone.getTimeZone(timezoneId))
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        if (weekendQuiet && (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY)) {
            return true
        }

        return if (startHour <= endHour) {
            currentHour in startHour until endHour
        } else {
            // e.g. 22:00 to 08:00
            currentHour >= startHour || currentHour < endHour
        }
    }

    fun sendTestNotification(context: Context): Result<String> {
        initNotificationChannels(context)

        if (!hasNotificationPermission(context)) {
            return Result.failure(
                SecurityException("Notification permission not granted. Please allow notification permission in app settings.")
            )
        }

        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                9999,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("GoalOS Notification Test")
                .setContentText("Notifications and alarm channels are verified and functioning.")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()

            nm.notify(9999, notification)
            return Result.success("Delivered successfully to system notification drawer.")
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    fun scheduleAlarmReminder(
        context: Context,
        item: NotificationItem,
        quietHoursStart: Int = 22,
        quietHoursEnd: Int = 8,
        weekendQuiet: Boolean = false
    ) {
        initNotificationChannels(context)

        val triggerTime = item.scheduledTime - (item.advanceWarningMinutes * 60000L)
        if (triggerTime <= System.currentTimeMillis()) return

        // If in quiet hours and not marked urgent, schedule after quiet hours
        var effectiveTrigger = triggerTime
        if (!item.isUrgent && isWithinQuietHours(quietHoursStart, quietHoursEnd, item.timezoneId, weekendQuiet)) {
            val cal = Calendar.getInstance(TimeZone.getTimeZone(item.timezoneId)).apply {
                timeInMillis = triggerTime
                if (get(Calendar.HOUR_OF_DAY) >= quietHoursStart) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
                set(Calendar.HOUR_OF_DAY, quietHoursEnd)
                set(Calendar.MINUTE, 5)
                set(Calendar.SECOND, 0)
            }
            effectiveTrigger = cal.timeInMillis
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, GoalOsAlarmReceiver::class.java).apply {
            action = ACTION_ALARM_TRIGGER
            putExtra(EXTRA_NOTIFICATION_ID, item.id)
            putExtra(EXTRA_TARGET_ID, item.targetId)
            putExtra(EXTRA_TARGET_TYPE, item.targetType)
            putExtra(EXTRA_TITLE, item.title)
            putExtra(EXTRA_MESSAGE, item.message)
        }

        val requestCode = item.id.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, effectiveTrigger, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, effectiveTrigger, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, effectiveTrigger, pendingIntent)
        }
    }

    fun cancelAlarmReminder(context: Context, notificationId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, GoalOsAlarmReceiver::class.java).apply {
            action = ACTION_ALARM_TRIGGER
        }
        val requestCode = notificationId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
