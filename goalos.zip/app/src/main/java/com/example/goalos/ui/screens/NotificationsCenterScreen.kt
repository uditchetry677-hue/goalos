package com.example.goalos.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.goalos.model.NotificationItem
import com.example.goalos.model.NotificationType
import com.example.goalos.ui.GoalOsViewModel
import com.example.goalos.ui.theme.StatusActiveColor
import com.example.goalos.ui.theme.StatusCompletedColor
import com.example.goalos.ui.theme.StatusOverdueColor
import com.example.goalos.ui.theme.StatusPausedColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class NotifFilter(val label: String) {
    ALL("All Alerts"),
    UNREAD("Unread"),
    TASK_REMINDERS("Task Reminders"),
    DEADLINES("Deadlines"),
    CUSTOM("Custom")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NotificationsCenterScreen(
    viewModel: GoalOsViewModel,
    onNavigateToGoalDetail: (String) -> Unit,
    onNavigateToTasks: () -> Unit,
    onOpenCreateReminder: () -> Unit,
    onOpenPreferences: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notifications by viewModel.inAppCenterNotifications.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()

    var selectedFilter by remember { mutableStateOf(NotifFilter.ALL) }
    var isGroupedView by remember(userSettings.groupRelatedAlerts) {
        mutableStateOf(userSettings.groupRelatedAlerts)
    }
    var testResultDialog by remember { mutableStateOf<String?>(null) }
    var showPreferencesDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Notification permission granted.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Notification permission was denied.", Toast.LENGTH_SHORT).show()
        }
    }

    val hasSystemPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else true

    val filteredList = notifications.filter { item ->
        when (selectedFilter) {
            NotifFilter.ALL -> !item.isDismissed
            NotifFilter.UNREAD -> !item.isRead && !item.isDismissed
            NotifFilter.TASK_REMINDERS -> item.type == NotificationType.TASK_REMINDER && !item.isDismissed
            NotifFilter.DEADLINES -> item.type in listOf(
                NotificationType.TASK_DEADLINE,
                NotificationType.MILESTONE_DEADLINE,
                NotificationType.GOAL_DEADLINE
            ) && !item.isDismissed
            NotifFilter.CUSTOM -> item.type in listOf(
                NotificationType.CUSTOM_REMINDER,
                NotificationType.DAILY_PLANNING,
                NotificationType.WEEKLY_REVIEW
            ) && !item.isDismissed
        }
    }

    Box(modifier = modifier.fillMaxSize().testTag("notifications_center_screen")) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Notification Centre",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = { showPreferencesDialog = true },
                            modifier = Modifier.testTag("btn_open_notif_prefs")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = "Preferences", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Reliable user-scheduled reminders, upcoming deadlines, and in-app alerts history.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // System Permission Banner if Android 13+ and not granted
            if (!hasSystemPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, StatusPausedColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        color = StatusPausedColor.copy(alpha = 0.1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.NotificationsOff, contentDescription = null, tint = StatusPausedColor)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Device Notifications Permission Needed",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Enable permission so alarms and deadline alerts trigger reliably on your phone.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                },
                                modifier = Modifier.testTag("request_notif_perm_btn")
                            ) {
                                Text("Allow")
                            }
                        }
                    }
                }
            }

            // Action Bar: Test Notification, Group Toggle & Clear Read
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val result = viewModel.triggerTestNotification()
                            if (result.isSuccess) {
                                testResultDialog = "Test Notification Result: ${result.getOrNull()}\n\nVerified: System channels, sound/vibrate, and foreground intent are operational."
                            } else {
                                testResultDialog = "Delivery Failed: ${result.exceptionOrNull()?.message}"
                            }
                        },
                        modifier = Modifier.weight(1.1f).testTag("btn_test_notification")
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test Alert", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            isGroupedView = !isGroupedView
                            viewModel.setGroupRelatedAlerts(isGroupedView)
                        },
                        modifier = Modifier.weight(1f).testTag("btn_group_related_toggle")
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isGroupedView) "Grouped" else "Flat", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.clearReadNotifications() },
                        modifier = Modifier.weight(1f).testTag("btn_clear_read_notifs")
                    ) {
                        Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear Read", fontSize = 12.sp)
                    }
                }
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    NotifFilter.entries.forEach { f ->
                        item {
                            FilterChip(
                                selected = selectedFilter == f,
                                onClick = { selectedFilter = f },
                                label = { Text(f.label) }
                            )
                        }
                    }
                }
            }

            // Notifications List or Empty State
            if (filteredList.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                            .padding(24.dp)
                            .testTag("notifs_empty_state"),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.Notifications,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No Scheduled Notifications",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Zero spam policy. Reminders only exist when you create them for specific goals or tasks.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = onOpenCreateReminder, modifier = Modifier.testTag("btn_create_first_reminder")) {
                                Icon(Icons.Default.AddAlert, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Schedule Reminder")
                            }
                        }
                    }
                }
            } else if (isGroupedView) {
                // Grouped by target
                val grouped = filteredList.groupBy { it.targetId ?: it.type.name }
                grouped.forEach { (key, groupItems) ->
                    val sample = groupItems.first()
                    val groupTitle = when {
                        sample.targetType == "GOAL" -> "Goal Alerts (${groupItems.size})"
                        sample.targetType == "TASK" -> "Task Alerts (${groupItems.size})"
                        sample.targetType == "MILESTONE" -> "Milestone Alerts (${groupItems.size})"
                        else -> "${sample.type.label} (${groupItems.size})"
                    }

                    item(key = "group_header_$key") {
                        Text(
                            text = groupTitle,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    items(groupItems, key = { it.id }) { item ->
                        NotificationCardItem(
                            item = item,
                            onMarkRead = { viewModel.markNotificationRead(item.id, !item.isRead) },
                            onSnooze = { mins -> viewModel.snoozeNotification(item.id, mins) },
                            onDismiss = { viewModel.dismissNotification(item.id) },
                            onOpen = {
                                if ((item.targetType == "GOAL" || item.targetType == "MILESTONE") && item.targetId != null) {
                                    onNavigateToGoalDetail(item.targetId)
                                } else {
                                    onNavigateToTasks()
                                }
                            }
                        )
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { item ->
                    NotificationCardItem(
                        item = item,
                        onMarkRead = { viewModel.markNotificationRead(item.id, !item.isRead) },
                        onSnooze = { mins -> viewModel.snoozeNotification(item.id, mins) },
                        onDismiss = { viewModel.dismissNotification(item.id) },
                        onOpen = {
                            if ((item.targetType == "GOAL" || item.targetType == "MILESTONE") && item.targetId != null) {
                                onNavigateToGoalDetail(item.targetId)
                            } else {
                                onNavigateToTasks()
                            }
                        }
                    )
                }
            }
        }

        // Floating Action Button to Schedule Reminder
        FloatingActionButton(
            onClick = onOpenCreateReminder,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("fab_create_reminder"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.AddAlert, contentDescription = "New Reminder")
        }
    }

    // Test Delivery Result Modal
    testResultDialog?.let { resultMsg ->
        AlertDialog(
            onDismissRequest = { testResultDialog = null },
            title = { Text("Notification Report") },
            text = { Text(resultMsg) },
            confirmButton = {
                Button(onClick = { testResultDialog = null }) {
                    Text("OK")
                }
            }
        )
    }

    // Preferences Dialog
    if (showPreferencesDialog) {
        NotificationPreferencesDialog(
            viewModel = viewModel,
            onDismiss = { showPreferencesDialog = false }
        )
    }
}

@Composable
fun NotificationCardItem(
    item: NotificationItem,
    onMarkRead: () -> Unit,
    onSnooze: (Int) -> Unit,
    onDismiss: () -> Unit,
    onOpen: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    val typeColor = when (item.type) {
        NotificationType.TASK_DEADLINE, NotificationType.GOAL_DEADLINE, NotificationType.MILESTONE_DEADLINE -> StatusOverdueColor
        NotificationType.TASK_REMINDER -> MaterialTheme.colorScheme.primary
        NotificationType.GOAL_REMINDER -> StatusActiveColor
        NotificationType.CUSTOM_REMINDER, NotificationType.DAILY_PLANNING, NotificationType.WEEKLY_REVIEW -> StatusPausedColor
        else -> MaterialTheme.colorScheme.primary
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                1.dp,
                if (!item.isRead) typeColor.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(14.dp)
            )
            .testTag("notif_item_${item.id}"),
        color = if (!item.isRead) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = typeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = item.type.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = typeColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 10.sp
                        )
                    }
                    if (item.targetType != null && item.targetType != "CUSTOM") {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = item.targetType,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Trigger: ${SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(item.scheduledTime))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = if (!item.isRead) FontWeight.Bold else FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (item.message.isNotBlank()) {
                Text(
                    text = item.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Creation timestamp & repeat rule display
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Created: ${SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(item.createdAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    fontSize = 10.sp
                )
                if (item.repeatRule != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Repeats: ${item.repeatRule.type.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.targetId != null) {
                    OutlinedButton(
                        onClick = onOpen,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open", fontSize = 12.sp)
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Snooze", fontSize = 12.sp)
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("15 Minutes") },
                            onClick = {
                                menuExpanded = false
                                onSnooze(15)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("1 Hour") },
                            onClick = {
                                menuExpanded = false
                                onSnooze(60)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Tomorrow (24 Hours)") },
                            onClick = {
                                menuExpanded = false
                                onSnooze(1440)
                            }
                        )
                    }
                }

                TextButton(
                    onClick = onMarkRead,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (item.isRead) "Mark Unread" else "Mark Read", fontSize = 12.sp)
                }
            }
        }
    }
}
